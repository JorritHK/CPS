git archive --format=tar --prefix=Bot1/ -o Bot1.tar HEAD
git archive --format=zip --prefix=Bot1/ -o Bot1.zip HEAD
