package life.game.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import life.game.services.GameOfLifeDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGameOfLifeDSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_STRING", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'empty'", "'survive'", "'die'", "'be born'", "'Coordinates'", "'='", "'['", "','", "']'", "'GridSize'", "'Initial:'", "'Patterns:'", "'x'", "'Rules:'", "'default:'", "'if'", "'companions'", "'active'", "'<'", "'>'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int RULE_ID=6;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalGameOfLifeDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGameOfLifeDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGameOfLifeDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGameOfLifeDSL.g"; }


    	private GameOfLifeDSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(GameOfLifeDSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleGameSpec"
    // InternalGameOfLifeDSL.g:53:1: entryRuleGameSpec : ruleGameSpec EOF ;
    public final void entryRuleGameSpec() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:54:1: ( ruleGameSpec EOF )
            // InternalGameOfLifeDSL.g:55:1: ruleGameSpec EOF
            {
             before(grammarAccess.getGameSpecRule()); 
            pushFollow(FOLLOW_1);
            ruleGameSpec();

            state._fsp--;

             after(grammarAccess.getGameSpecRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGameSpec"


    // $ANTLR start "ruleGameSpec"
    // InternalGameOfLifeDSL.g:62:1: ruleGameSpec : ( ( rule__GameSpec__Group__0 ) ) ;
    public final void ruleGameSpec() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:66:2: ( ( ( rule__GameSpec__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:67:2: ( ( rule__GameSpec__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:67:2: ( ( rule__GameSpec__Group__0 ) )
            // InternalGameOfLifeDSL.g:68:3: ( rule__GameSpec__Group__0 )
            {
             before(grammarAccess.getGameSpecAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:69:3: ( rule__GameSpec__Group__0 )
            // InternalGameOfLifeDSL.g:69:4: rule__GameSpec__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GameSpec__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGameSpecAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGameSpec"


    // $ANTLR start "entryRuleCoordinates"
    // InternalGameOfLifeDSL.g:78:1: entryRuleCoordinates : ruleCoordinates EOF ;
    public final void entryRuleCoordinates() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:79:1: ( ruleCoordinates EOF )
            // InternalGameOfLifeDSL.g:80:1: ruleCoordinates EOF
            {
             before(grammarAccess.getCoordinatesRule()); 
            pushFollow(FOLLOW_1);
            ruleCoordinates();

            state._fsp--;

             after(grammarAccess.getCoordinatesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCoordinates"


    // $ANTLR start "ruleCoordinates"
    // InternalGameOfLifeDSL.g:87:1: ruleCoordinates : ( ( rule__Coordinates__Group__0 ) ) ;
    public final void ruleCoordinates() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:91:2: ( ( ( rule__Coordinates__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:92:2: ( ( rule__Coordinates__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:92:2: ( ( rule__Coordinates__Group__0 ) )
            // InternalGameOfLifeDSL.g:93:3: ( rule__Coordinates__Group__0 )
            {
             before(grammarAccess.getCoordinatesAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:94:3: ( rule__Coordinates__Group__0 )
            // InternalGameOfLifeDSL.g:94:4: rule__Coordinates__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Coordinates__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCoordinatesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoordinates"


    // $ANTLR start "entryRuleCoordinate"
    // InternalGameOfLifeDSL.g:103:1: entryRuleCoordinate : ruleCoordinate EOF ;
    public final void entryRuleCoordinate() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:104:1: ( ruleCoordinate EOF )
            // InternalGameOfLifeDSL.g:105:1: ruleCoordinate EOF
            {
             before(grammarAccess.getCoordinateRule()); 
            pushFollow(FOLLOW_1);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getCoordinateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCoordinate"


    // $ANTLR start "ruleCoordinate"
    // InternalGameOfLifeDSL.g:112:1: ruleCoordinate : ( ( rule__Coordinate__Group__0 ) ) ;
    public final void ruleCoordinate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:116:2: ( ( ( rule__Coordinate__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:117:2: ( ( rule__Coordinate__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:117:2: ( ( rule__Coordinate__Group__0 ) )
            // InternalGameOfLifeDSL.g:118:3: ( rule__Coordinate__Group__0 )
            {
             before(grammarAccess.getCoordinateAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:119:3: ( rule__Coordinate__Group__0 )
            // InternalGameOfLifeDSL.g:119:4: rule__Coordinate__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoordinate"


    // $ANTLR start "entryRuleGridSize"
    // InternalGameOfLifeDSL.g:128:1: entryRuleGridSize : ruleGridSize EOF ;
    public final void entryRuleGridSize() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:129:1: ( ruleGridSize EOF )
            // InternalGameOfLifeDSL.g:130:1: ruleGridSize EOF
            {
             before(grammarAccess.getGridSizeRule()); 
            pushFollow(FOLLOW_1);
            ruleGridSize();

            state._fsp--;

             after(grammarAccess.getGridSizeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGridSize"


    // $ANTLR start "ruleGridSize"
    // InternalGameOfLifeDSL.g:137:1: ruleGridSize : ( ( rule__GridSize__Group__0 ) ) ;
    public final void ruleGridSize() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:141:2: ( ( ( rule__GridSize__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:142:2: ( ( rule__GridSize__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:142:2: ( ( rule__GridSize__Group__0 ) )
            // InternalGameOfLifeDSL.g:143:3: ( rule__GridSize__Group__0 )
            {
             before(grammarAccess.getGridSizeAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:144:3: ( rule__GridSize__Group__0 )
            // InternalGameOfLifeDSL.g:144:4: rule__GridSize__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GridSize__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGridSizeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGridSize"


    // $ANTLR start "entryRuleInitial"
    // InternalGameOfLifeDSL.g:153:1: entryRuleInitial : ruleInitial EOF ;
    public final void entryRuleInitial() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:154:1: ( ruleInitial EOF )
            // InternalGameOfLifeDSL.g:155:1: ruleInitial EOF
            {
             before(grammarAccess.getInitialRule()); 
            pushFollow(FOLLOW_1);
            ruleInitial();

            state._fsp--;

             after(grammarAccess.getInitialRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInitial"


    // $ANTLR start "ruleInitial"
    // InternalGameOfLifeDSL.g:162:1: ruleInitial : ( ( rule__Initial__Group__0 ) ) ;
    public final void ruleInitial() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:166:2: ( ( ( rule__Initial__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:167:2: ( ( rule__Initial__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:167:2: ( ( rule__Initial__Group__0 ) )
            // InternalGameOfLifeDSL.g:168:3: ( rule__Initial__Group__0 )
            {
             before(grammarAccess.getInitialAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:169:3: ( rule__Initial__Group__0 )
            // InternalGameOfLifeDSL.g:169:4: rule__Initial__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Initial__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInitialAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInitial"


    // $ANTLR start "entryRulePatternRLE"
    // InternalGameOfLifeDSL.g:178:1: entryRulePatternRLE : rulePatternRLE EOF ;
    public final void entryRulePatternRLE() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:179:1: ( rulePatternRLE EOF )
            // InternalGameOfLifeDSL.g:180:1: rulePatternRLE EOF
            {
             before(grammarAccess.getPatternRLERule()); 
            pushFollow(FOLLOW_1);
            rulePatternRLE();

            state._fsp--;

             after(grammarAccess.getPatternRLERule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePatternRLE"


    // $ANTLR start "rulePatternRLE"
    // InternalGameOfLifeDSL.g:187:1: rulePatternRLE : ( ( rule__PatternRLE__Group__0 ) ) ;
    public final void rulePatternRLE() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:191:2: ( ( ( rule__PatternRLE__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:192:2: ( ( rule__PatternRLE__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:192:2: ( ( rule__PatternRLE__Group__0 ) )
            // InternalGameOfLifeDSL.g:193:3: ( rule__PatternRLE__Group__0 )
            {
             before(grammarAccess.getPatternRLEAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:194:3: ( rule__PatternRLE__Group__0 )
            // InternalGameOfLifeDSL.g:194:4: rule__PatternRLE__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PatternRLE__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPatternRLEAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePatternRLE"


    // $ANTLR start "entryRuleGrid"
    // InternalGameOfLifeDSL.g:203:1: entryRuleGrid : ruleGrid EOF ;
    public final void entryRuleGrid() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:204:1: ( ruleGrid EOF )
            // InternalGameOfLifeDSL.g:205:1: ruleGrid EOF
            {
             before(grammarAccess.getGridRule()); 
            pushFollow(FOLLOW_1);
            ruleGrid();

            state._fsp--;

             after(grammarAccess.getGridRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGrid"


    // $ANTLR start "ruleGrid"
    // InternalGameOfLifeDSL.g:212:1: ruleGrid : ( ( rule__Grid__Group__0 ) ) ;
    public final void ruleGrid() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:216:2: ( ( ( rule__Grid__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:217:2: ( ( rule__Grid__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:217:2: ( ( rule__Grid__Group__0 ) )
            // InternalGameOfLifeDSL.g:218:3: ( rule__Grid__Group__0 )
            {
             before(grammarAccess.getGridAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:219:3: ( rule__Grid__Group__0 )
            // InternalGameOfLifeDSL.g:219:4: rule__Grid__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Grid__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGridAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGrid"


    // $ANTLR start "entryRuleRules"
    // InternalGameOfLifeDSL.g:228:1: entryRuleRules : ruleRules EOF ;
    public final void entryRuleRules() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:229:1: ( ruleRules EOF )
            // InternalGameOfLifeDSL.g:230:1: ruleRules EOF
            {
             before(grammarAccess.getRulesRule()); 
            pushFollow(FOLLOW_1);
            ruleRules();

            state._fsp--;

             after(grammarAccess.getRulesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRules"


    // $ANTLR start "ruleRules"
    // InternalGameOfLifeDSL.g:237:1: ruleRules : ( ( rule__Rules__Group__0 ) ) ;
    public final void ruleRules() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:241:2: ( ( ( rule__Rules__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:242:2: ( ( rule__Rules__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:242:2: ( ( rule__Rules__Group__0 ) )
            // InternalGameOfLifeDSL.g:243:3: ( rule__Rules__Group__0 )
            {
             before(grammarAccess.getRulesAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:244:3: ( rule__Rules__Group__0 )
            // InternalGameOfLifeDSL.g:244:4: rule__Rules__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Rules__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRulesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRules"


    // $ANTLR start "entryRuleRule"
    // InternalGameOfLifeDSL.g:253:1: entryRuleRule : ruleRule EOF ;
    public final void entryRuleRule() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:254:1: ( ruleRule EOF )
            // InternalGameOfLifeDSL.g:255:1: ruleRule EOF
            {
             before(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getRuleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalGameOfLifeDSL.g:262:1: ruleRule : ( ( rule__Rule__Group__0 ) ) ;
    public final void ruleRule() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:266:2: ( ( ( rule__Rule__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:267:2: ( ( rule__Rule__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:267:2: ( ( rule__Rule__Group__0 ) )
            // InternalGameOfLifeDSL.g:268:3: ( rule__Rule__Group__0 )
            {
             before(grammarAccess.getRuleAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:269:3: ( rule__Rule__Group__0 )
            // InternalGameOfLifeDSL.g:269:4: rule__Rule__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Rule__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleReason"
    // InternalGameOfLifeDSL.g:278:1: entryRuleReason : ruleReason EOF ;
    public final void entryRuleReason() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:279:1: ( ruleReason EOF )
            // InternalGameOfLifeDSL.g:280:1: ruleReason EOF
            {
             before(grammarAccess.getReasonRule()); 
            pushFollow(FOLLOW_1);
            ruleReason();

            state._fsp--;

             after(grammarAccess.getReasonRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleReason"


    // $ANTLR start "ruleReason"
    // InternalGameOfLifeDSL.g:287:1: ruleReason : ( ( rule__Reason__Group__0 ) ) ;
    public final void ruleReason() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:291:2: ( ( ( rule__Reason__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:292:2: ( ( rule__Reason__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:292:2: ( ( rule__Reason__Group__0 ) )
            // InternalGameOfLifeDSL.g:293:3: ( rule__Reason__Group__0 )
            {
             before(grammarAccess.getReasonAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:294:3: ( rule__Reason__Group__0 )
            // InternalGameOfLifeDSL.g:294:4: rule__Reason__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Reason__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReasonAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleReason"


    // $ANTLR start "entryRuleCondition"
    // InternalGameOfLifeDSL.g:303:1: entryRuleCondition : ruleCondition EOF ;
    public final void entryRuleCondition() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:304:1: ( ruleCondition EOF )
            // InternalGameOfLifeDSL.g:305:1: ruleCondition EOF
            {
             before(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalGameOfLifeDSL.g:312:1: ruleCondition : ( ( rule__Condition__Group__0 ) ) ;
    public final void ruleCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:316:2: ( ( ( rule__Condition__Group__0 ) ) )
            // InternalGameOfLifeDSL.g:317:2: ( ( rule__Condition__Group__0 ) )
            {
            // InternalGameOfLifeDSL.g:317:2: ( ( rule__Condition__Group__0 ) )
            // InternalGameOfLifeDSL.g:318:3: ( rule__Condition__Group__0 )
            {
             before(grammarAccess.getConditionAccess().getGroup()); 
            // InternalGameOfLifeDSL.g:319:3: ( rule__Condition__Group__0 )
            // InternalGameOfLifeDSL.g:319:4: rule__Condition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleOperator"
    // InternalGameOfLifeDSL.g:328:1: entryRuleOperator : ruleOperator EOF ;
    public final void entryRuleOperator() throws RecognitionException {
        try {
            // InternalGameOfLifeDSL.g:329:1: ( ruleOperator EOF )
            // InternalGameOfLifeDSL.g:330:1: ruleOperator EOF
            {
             before(grammarAccess.getOperatorRule()); 
            pushFollow(FOLLOW_1);
            ruleOperator();

            state._fsp--;

             after(grammarAccess.getOperatorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOperator"


    // $ANTLR start "ruleOperator"
    // InternalGameOfLifeDSL.g:337:1: ruleOperator : ( ( rule__Operator__Alternatives ) ) ;
    public final void ruleOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:341:2: ( ( ( rule__Operator__Alternatives ) ) )
            // InternalGameOfLifeDSL.g:342:2: ( ( rule__Operator__Alternatives ) )
            {
            // InternalGameOfLifeDSL.g:342:2: ( ( rule__Operator__Alternatives ) )
            // InternalGameOfLifeDSL.g:343:3: ( rule__Operator__Alternatives )
            {
             before(grammarAccess.getOperatorAccess().getAlternatives()); 
            // InternalGameOfLifeDSL.g:344:3: ( rule__Operator__Alternatives )
            // InternalGameOfLifeDSL.g:344:4: rule__Operator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Operator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOperator"


    // $ANTLR start "ruleDefaultConsequence"
    // InternalGameOfLifeDSL.g:353:1: ruleDefaultConsequence : ( ( rule__DefaultConsequence__Alternatives ) ) ;
    public final void ruleDefaultConsequence() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:357:1: ( ( ( rule__DefaultConsequence__Alternatives ) ) )
            // InternalGameOfLifeDSL.g:358:2: ( ( rule__DefaultConsequence__Alternatives ) )
            {
            // InternalGameOfLifeDSL.g:358:2: ( ( rule__DefaultConsequence__Alternatives ) )
            // InternalGameOfLifeDSL.g:359:3: ( rule__DefaultConsequence__Alternatives )
            {
             before(grammarAccess.getDefaultConsequenceAccess().getAlternatives()); 
            // InternalGameOfLifeDSL.g:360:3: ( rule__DefaultConsequence__Alternatives )
            // InternalGameOfLifeDSL.g:360:4: rule__DefaultConsequence__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DefaultConsequence__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDefaultConsequenceAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDefaultConsequence"


    // $ANTLR start "ruleConsequence"
    // InternalGameOfLifeDSL.g:369:1: ruleConsequence : ( ( rule__Consequence__Alternatives ) ) ;
    public final void ruleConsequence() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:373:1: ( ( ( rule__Consequence__Alternatives ) ) )
            // InternalGameOfLifeDSL.g:374:2: ( ( rule__Consequence__Alternatives ) )
            {
            // InternalGameOfLifeDSL.g:374:2: ( ( rule__Consequence__Alternatives ) )
            // InternalGameOfLifeDSL.g:375:3: ( rule__Consequence__Alternatives )
            {
             before(grammarAccess.getConsequenceAccess().getAlternatives()); 
            // InternalGameOfLifeDSL.g:376:3: ( rule__Consequence__Alternatives )
            // InternalGameOfLifeDSL.g:376:4: rule__Consequence__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Consequence__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getConsequenceAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConsequence"


    // $ANTLR start "rule__Operator__Alternatives"
    // InternalGameOfLifeDSL.g:384:1: rule__Operator__Alternatives : ( ( ( rule__Operator__SMALLERAssignment_0 ) ) | ( ( rule__Operator__LARGERAssignment_1 ) ) | ( ( rule__Operator__EQUALAssignment_2 ) ) );
    public final void rule__Operator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:388:1: ( ( ( rule__Operator__SMALLERAssignment_0 ) ) | ( ( rule__Operator__LARGERAssignment_1 ) ) | ( ( rule__Operator__EQUALAssignment_2 ) ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt1=1;
                }
                break;
            case 30:
                {
                alt1=2;
                }
                break;
            case 16:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalGameOfLifeDSL.g:389:2: ( ( rule__Operator__SMALLERAssignment_0 ) )
                    {
                    // InternalGameOfLifeDSL.g:389:2: ( ( rule__Operator__SMALLERAssignment_0 ) )
                    // InternalGameOfLifeDSL.g:390:3: ( rule__Operator__SMALLERAssignment_0 )
                    {
                     before(grammarAccess.getOperatorAccess().getSMALLERAssignment_0()); 
                    // InternalGameOfLifeDSL.g:391:3: ( rule__Operator__SMALLERAssignment_0 )
                    // InternalGameOfLifeDSL.g:391:4: rule__Operator__SMALLERAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Operator__SMALLERAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getOperatorAccess().getSMALLERAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:395:2: ( ( rule__Operator__LARGERAssignment_1 ) )
                    {
                    // InternalGameOfLifeDSL.g:395:2: ( ( rule__Operator__LARGERAssignment_1 ) )
                    // InternalGameOfLifeDSL.g:396:3: ( rule__Operator__LARGERAssignment_1 )
                    {
                     before(grammarAccess.getOperatorAccess().getLARGERAssignment_1()); 
                    // InternalGameOfLifeDSL.g:397:3: ( rule__Operator__LARGERAssignment_1 )
                    // InternalGameOfLifeDSL.g:397:4: rule__Operator__LARGERAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Operator__LARGERAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getOperatorAccess().getLARGERAssignment_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:401:2: ( ( rule__Operator__EQUALAssignment_2 ) )
                    {
                    // InternalGameOfLifeDSL.g:401:2: ( ( rule__Operator__EQUALAssignment_2 ) )
                    // InternalGameOfLifeDSL.g:402:3: ( rule__Operator__EQUALAssignment_2 )
                    {
                     before(grammarAccess.getOperatorAccess().getEQUALAssignment_2()); 
                    // InternalGameOfLifeDSL.g:403:3: ( rule__Operator__EQUALAssignment_2 )
                    // InternalGameOfLifeDSL.g:403:4: rule__Operator__EQUALAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Operator__EQUALAssignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getOperatorAccess().getEQUALAssignment_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Operator__Alternatives"


    // $ANTLR start "rule__DefaultConsequence__Alternatives"
    // InternalGameOfLifeDSL.g:411:1: rule__DefaultConsequence__Alternatives : ( ( ( 'empty' ) ) | ( ( 'survive' ) ) | ( ( 'die' ) ) );
    public final void rule__DefaultConsequence__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:415:1: ( ( ( 'empty' ) ) | ( ( 'survive' ) ) | ( ( 'die' ) ) )
            int alt2=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 12:
                {
                alt2=2;
                }
                break;
            case 13:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalGameOfLifeDSL.g:416:2: ( ( 'empty' ) )
                    {
                    // InternalGameOfLifeDSL.g:416:2: ( ( 'empty' ) )
                    // InternalGameOfLifeDSL.g:417:3: ( 'empty' )
                    {
                     before(grammarAccess.getDefaultConsequenceAccess().getEMPTYEnumLiteralDeclaration_0()); 
                    // InternalGameOfLifeDSL.g:418:3: ( 'empty' )
                    // InternalGameOfLifeDSL.g:418:4: 'empty'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getDefaultConsequenceAccess().getEMPTYEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:422:2: ( ( 'survive' ) )
                    {
                    // InternalGameOfLifeDSL.g:422:2: ( ( 'survive' ) )
                    // InternalGameOfLifeDSL.g:423:3: ( 'survive' )
                    {
                     before(grammarAccess.getDefaultConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1()); 
                    // InternalGameOfLifeDSL.g:424:3: ( 'survive' )
                    // InternalGameOfLifeDSL.g:424:4: 'survive'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getDefaultConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:428:2: ( ( 'die' ) )
                    {
                    // InternalGameOfLifeDSL.g:428:2: ( ( 'die' ) )
                    // InternalGameOfLifeDSL.g:429:3: ( 'die' )
                    {
                     before(grammarAccess.getDefaultConsequenceAccess().getDEATHEnumLiteralDeclaration_2()); 
                    // InternalGameOfLifeDSL.g:430:3: ( 'die' )
                    // InternalGameOfLifeDSL.g:430:4: 'die'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getDefaultConsequenceAccess().getDEATHEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DefaultConsequence__Alternatives"


    // $ANTLR start "rule__Consequence__Alternatives"
    // InternalGameOfLifeDSL.g:438:1: rule__Consequence__Alternatives : ( ( ( 'die' ) ) | ( ( 'survive' ) ) | ( ( 'be born' ) ) );
    public final void rule__Consequence__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:442:1: ( ( ( 'die' ) ) | ( ( 'survive' ) ) | ( ( 'be born' ) ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt3=1;
                }
                break;
            case 12:
                {
                alt3=2;
                }
                break;
            case 14:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalGameOfLifeDSL.g:443:2: ( ( 'die' ) )
                    {
                    // InternalGameOfLifeDSL.g:443:2: ( ( 'die' ) )
                    // InternalGameOfLifeDSL.g:444:3: ( 'die' )
                    {
                     before(grammarAccess.getConsequenceAccess().getDEATHEnumLiteralDeclaration_0()); 
                    // InternalGameOfLifeDSL.g:445:3: ( 'die' )
                    // InternalGameOfLifeDSL.g:445:4: 'die'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getConsequenceAccess().getDEATHEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:449:2: ( ( 'survive' ) )
                    {
                    // InternalGameOfLifeDSL.g:449:2: ( ( 'survive' ) )
                    // InternalGameOfLifeDSL.g:450:3: ( 'survive' )
                    {
                     before(grammarAccess.getConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1()); 
                    // InternalGameOfLifeDSL.g:451:3: ( 'survive' )
                    // InternalGameOfLifeDSL.g:451:4: 'survive'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:455:2: ( ( 'be born' ) )
                    {
                    // InternalGameOfLifeDSL.g:455:2: ( ( 'be born' ) )
                    // InternalGameOfLifeDSL.g:456:3: ( 'be born' )
                    {
                     before(grammarAccess.getConsequenceAccess().getBORNEnumLiteralDeclaration_2()); 
                    // InternalGameOfLifeDSL.g:457:3: ( 'be born' )
                    // InternalGameOfLifeDSL.g:457:4: 'be born'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getConsequenceAccess().getBORNEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Consequence__Alternatives"


    // $ANTLR start "rule__GameSpec__Group__0"
    // InternalGameOfLifeDSL.g:465:1: rule__GameSpec__Group__0 : rule__GameSpec__Group__0__Impl rule__GameSpec__Group__1 ;
    public final void rule__GameSpec__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:469:1: ( rule__GameSpec__Group__0__Impl rule__GameSpec__Group__1 )
            // InternalGameOfLifeDSL.g:470:2: rule__GameSpec__Group__0__Impl rule__GameSpec__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__GameSpec__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameSpec__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__0"


    // $ANTLR start "rule__GameSpec__Group__0__Impl"
    // InternalGameOfLifeDSL.g:477:1: rule__GameSpec__Group__0__Impl : ( ( rule__GameSpec__ActiveAssignment_0 )? ) ;
    public final void rule__GameSpec__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:481:1: ( ( ( rule__GameSpec__ActiveAssignment_0 )? ) )
            // InternalGameOfLifeDSL.g:482:1: ( ( rule__GameSpec__ActiveAssignment_0 )? )
            {
            // InternalGameOfLifeDSL.g:482:1: ( ( rule__GameSpec__ActiveAssignment_0 )? )
            // InternalGameOfLifeDSL.g:483:2: ( rule__GameSpec__ActiveAssignment_0 )?
            {
             before(grammarAccess.getGameSpecAccess().getActiveAssignment_0()); 
            // InternalGameOfLifeDSL.g:484:2: ( rule__GameSpec__ActiveAssignment_0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==28) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalGameOfLifeDSL.g:484:3: rule__GameSpec__ActiveAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameSpec__ActiveAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameSpecAccess().getActiveAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__0__Impl"


    // $ANTLR start "rule__GameSpec__Group__1"
    // InternalGameOfLifeDSL.g:492:1: rule__GameSpec__Group__1 : rule__GameSpec__Group__1__Impl rule__GameSpec__Group__2 ;
    public final void rule__GameSpec__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:496:1: ( rule__GameSpec__Group__1__Impl rule__GameSpec__Group__2 )
            // InternalGameOfLifeDSL.g:497:2: rule__GameSpec__Group__1__Impl rule__GameSpec__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__GameSpec__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameSpec__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__1"


    // $ANTLR start "rule__GameSpec__Group__1__Impl"
    // InternalGameOfLifeDSL.g:504:1: rule__GameSpec__Group__1__Impl : ( ( rule__GameSpec__GridAssignment_1 )? ) ;
    public final void rule__GameSpec__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:508:1: ( ( ( rule__GameSpec__GridAssignment_1 )? ) )
            // InternalGameOfLifeDSL.g:509:1: ( ( rule__GameSpec__GridAssignment_1 )? )
            {
            // InternalGameOfLifeDSL.g:509:1: ( ( rule__GameSpec__GridAssignment_1 )? )
            // InternalGameOfLifeDSL.g:510:2: ( rule__GameSpec__GridAssignment_1 )?
            {
             before(grammarAccess.getGameSpecAccess().getGridAssignment_1()); 
            // InternalGameOfLifeDSL.g:511:2: ( rule__GameSpec__GridAssignment_1 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==20) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalGameOfLifeDSL.g:511:3: rule__GameSpec__GridAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameSpec__GridAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameSpecAccess().getGridAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__1__Impl"


    // $ANTLR start "rule__GameSpec__Group__2"
    // InternalGameOfLifeDSL.g:519:1: rule__GameSpec__Group__2 : rule__GameSpec__Group__2__Impl rule__GameSpec__Group__3 ;
    public final void rule__GameSpec__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:523:1: ( rule__GameSpec__Group__2__Impl rule__GameSpec__Group__3 )
            // InternalGameOfLifeDSL.g:524:2: rule__GameSpec__Group__2__Impl rule__GameSpec__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__GameSpec__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameSpec__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__2"


    // $ANTLR start "rule__GameSpec__Group__2__Impl"
    // InternalGameOfLifeDSL.g:531:1: rule__GameSpec__Group__2__Impl : ( ( rule__GameSpec__InitialAssignment_2 )? ) ;
    public final void rule__GameSpec__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:535:1: ( ( ( rule__GameSpec__InitialAssignment_2 )? ) )
            // InternalGameOfLifeDSL.g:536:1: ( ( rule__GameSpec__InitialAssignment_2 )? )
            {
            // InternalGameOfLifeDSL.g:536:1: ( ( rule__GameSpec__InitialAssignment_2 )? )
            // InternalGameOfLifeDSL.g:537:2: ( rule__GameSpec__InitialAssignment_2 )?
            {
             before(grammarAccess.getGameSpecAccess().getInitialAssignment_2()); 
            // InternalGameOfLifeDSL.g:538:2: ( rule__GameSpec__InitialAssignment_2 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==21) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalGameOfLifeDSL.g:538:3: rule__GameSpec__InitialAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameSpec__InitialAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameSpecAccess().getInitialAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__2__Impl"


    // $ANTLR start "rule__GameSpec__Group__3"
    // InternalGameOfLifeDSL.g:546:1: rule__GameSpec__Group__3 : rule__GameSpec__Group__3__Impl ;
    public final void rule__GameSpec__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:550:1: ( rule__GameSpec__Group__3__Impl )
            // InternalGameOfLifeDSL.g:551:2: rule__GameSpec__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameSpec__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__3"


    // $ANTLR start "rule__GameSpec__Group__3__Impl"
    // InternalGameOfLifeDSL.g:557:1: rule__GameSpec__Group__3__Impl : ( ( rule__GameSpec__RulesAssignment_3 ) ) ;
    public final void rule__GameSpec__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:561:1: ( ( ( rule__GameSpec__RulesAssignment_3 ) ) )
            // InternalGameOfLifeDSL.g:562:1: ( ( rule__GameSpec__RulesAssignment_3 ) )
            {
            // InternalGameOfLifeDSL.g:562:1: ( ( rule__GameSpec__RulesAssignment_3 ) )
            // InternalGameOfLifeDSL.g:563:2: ( rule__GameSpec__RulesAssignment_3 )
            {
             before(grammarAccess.getGameSpecAccess().getRulesAssignment_3()); 
            // InternalGameOfLifeDSL.g:564:2: ( rule__GameSpec__RulesAssignment_3 )
            // InternalGameOfLifeDSL.g:564:3: rule__GameSpec__RulesAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__GameSpec__RulesAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getGameSpecAccess().getRulesAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__Group__3__Impl"


    // $ANTLR start "rule__Coordinates__Group__0"
    // InternalGameOfLifeDSL.g:573:1: rule__Coordinates__Group__0 : rule__Coordinates__Group__0__Impl rule__Coordinates__Group__1 ;
    public final void rule__Coordinates__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:577:1: ( rule__Coordinates__Group__0__Impl rule__Coordinates__Group__1 )
            // InternalGameOfLifeDSL.g:578:2: rule__Coordinates__Group__0__Impl rule__Coordinates__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Coordinates__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinates__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__0"


    // $ANTLR start "rule__Coordinates__Group__0__Impl"
    // InternalGameOfLifeDSL.g:585:1: rule__Coordinates__Group__0__Impl : ( () ) ;
    public final void rule__Coordinates__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:589:1: ( ( () ) )
            // InternalGameOfLifeDSL.g:590:1: ( () )
            {
            // InternalGameOfLifeDSL.g:590:1: ( () )
            // InternalGameOfLifeDSL.g:591:2: ()
            {
             before(grammarAccess.getCoordinatesAccess().getCoordinatesAction_0()); 
            // InternalGameOfLifeDSL.g:592:2: ()
            // InternalGameOfLifeDSL.g:592:3: 
            {
            }

             after(grammarAccess.getCoordinatesAccess().getCoordinatesAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__0__Impl"


    // $ANTLR start "rule__Coordinates__Group__1"
    // InternalGameOfLifeDSL.g:600:1: rule__Coordinates__Group__1 : rule__Coordinates__Group__1__Impl rule__Coordinates__Group__2 ;
    public final void rule__Coordinates__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:604:1: ( rule__Coordinates__Group__1__Impl rule__Coordinates__Group__2 )
            // InternalGameOfLifeDSL.g:605:2: rule__Coordinates__Group__1__Impl rule__Coordinates__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Coordinates__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinates__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__1"


    // $ANTLR start "rule__Coordinates__Group__1__Impl"
    // InternalGameOfLifeDSL.g:612:1: rule__Coordinates__Group__1__Impl : ( 'Coordinates' ) ;
    public final void rule__Coordinates__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:616:1: ( ( 'Coordinates' ) )
            // InternalGameOfLifeDSL.g:617:1: ( 'Coordinates' )
            {
            // InternalGameOfLifeDSL.g:617:1: ( 'Coordinates' )
            // InternalGameOfLifeDSL.g:618:2: 'Coordinates'
            {
             before(grammarAccess.getCoordinatesAccess().getCoordinatesKeyword_1()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getCoordinatesAccess().getCoordinatesKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__1__Impl"


    // $ANTLR start "rule__Coordinates__Group__2"
    // InternalGameOfLifeDSL.g:627:1: rule__Coordinates__Group__2 : rule__Coordinates__Group__2__Impl rule__Coordinates__Group__3 ;
    public final void rule__Coordinates__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:631:1: ( rule__Coordinates__Group__2__Impl rule__Coordinates__Group__3 )
            // InternalGameOfLifeDSL.g:632:2: rule__Coordinates__Group__2__Impl rule__Coordinates__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__Coordinates__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinates__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__2"


    // $ANTLR start "rule__Coordinates__Group__2__Impl"
    // InternalGameOfLifeDSL.g:639:1: rule__Coordinates__Group__2__Impl : ( '=' ) ;
    public final void rule__Coordinates__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:643:1: ( ( '=' ) )
            // InternalGameOfLifeDSL.g:644:1: ( '=' )
            {
            // InternalGameOfLifeDSL.g:644:1: ( '=' )
            // InternalGameOfLifeDSL.g:645:2: '='
            {
             before(grammarAccess.getCoordinatesAccess().getEqualsSignKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getCoordinatesAccess().getEqualsSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__2__Impl"


    // $ANTLR start "rule__Coordinates__Group__3"
    // InternalGameOfLifeDSL.g:654:1: rule__Coordinates__Group__3 : rule__Coordinates__Group__3__Impl ;
    public final void rule__Coordinates__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:658:1: ( rule__Coordinates__Group__3__Impl )
            // InternalGameOfLifeDSL.g:659:2: rule__Coordinates__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Coordinates__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__3"


    // $ANTLR start "rule__Coordinates__Group__3__Impl"
    // InternalGameOfLifeDSL.g:665:1: rule__Coordinates__Group__3__Impl : ( ( rule__Coordinates__CoordlistAssignment_3 )* ) ;
    public final void rule__Coordinates__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:669:1: ( ( ( rule__Coordinates__CoordlistAssignment_3 )* ) )
            // InternalGameOfLifeDSL.g:670:1: ( ( rule__Coordinates__CoordlistAssignment_3 )* )
            {
            // InternalGameOfLifeDSL.g:670:1: ( ( rule__Coordinates__CoordlistAssignment_3 )* )
            // InternalGameOfLifeDSL.g:671:2: ( rule__Coordinates__CoordlistAssignment_3 )*
            {
             before(grammarAccess.getCoordinatesAccess().getCoordlistAssignment_3()); 
            // InternalGameOfLifeDSL.g:672:2: ( rule__Coordinates__CoordlistAssignment_3 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==17) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalGameOfLifeDSL.g:672:3: rule__Coordinates__CoordlistAssignment_3
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Coordinates__CoordlistAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getCoordinatesAccess().getCoordlistAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__Group__3__Impl"


    // $ANTLR start "rule__Coordinate__Group__0"
    // InternalGameOfLifeDSL.g:681:1: rule__Coordinate__Group__0 : rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1 ;
    public final void rule__Coordinate__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:685:1: ( rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1 )
            // InternalGameOfLifeDSL.g:686:2: rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Coordinate__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__0"


    // $ANTLR start "rule__Coordinate__Group__0__Impl"
    // InternalGameOfLifeDSL.g:693:1: rule__Coordinate__Group__0__Impl : ( '[' ) ;
    public final void rule__Coordinate__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:697:1: ( ( '[' ) )
            // InternalGameOfLifeDSL.g:698:1: ( '[' )
            {
            // InternalGameOfLifeDSL.g:698:1: ( '[' )
            // InternalGameOfLifeDSL.g:699:2: '['
            {
             before(grammarAccess.getCoordinateAccess().getLeftSquareBracketKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getCoordinateAccess().getLeftSquareBracketKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__0__Impl"


    // $ANTLR start "rule__Coordinate__Group__1"
    // InternalGameOfLifeDSL.g:708:1: rule__Coordinate__Group__1 : rule__Coordinate__Group__1__Impl rule__Coordinate__Group__2 ;
    public final void rule__Coordinate__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:712:1: ( rule__Coordinate__Group__1__Impl rule__Coordinate__Group__2 )
            // InternalGameOfLifeDSL.g:713:2: rule__Coordinate__Group__1__Impl rule__Coordinate__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Coordinate__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__1"


    // $ANTLR start "rule__Coordinate__Group__1__Impl"
    // InternalGameOfLifeDSL.g:720:1: rule__Coordinate__Group__1__Impl : ( ( rule__Coordinate__XAssignment_1 ) ) ;
    public final void rule__Coordinate__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:724:1: ( ( ( rule__Coordinate__XAssignment_1 ) ) )
            // InternalGameOfLifeDSL.g:725:1: ( ( rule__Coordinate__XAssignment_1 ) )
            {
            // InternalGameOfLifeDSL.g:725:1: ( ( rule__Coordinate__XAssignment_1 ) )
            // InternalGameOfLifeDSL.g:726:2: ( rule__Coordinate__XAssignment_1 )
            {
             before(grammarAccess.getCoordinateAccess().getXAssignment_1()); 
            // InternalGameOfLifeDSL.g:727:2: ( rule__Coordinate__XAssignment_1 )
            // InternalGameOfLifeDSL.g:727:3: rule__Coordinate__XAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__XAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getXAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__1__Impl"


    // $ANTLR start "rule__Coordinate__Group__2"
    // InternalGameOfLifeDSL.g:735:1: rule__Coordinate__Group__2 : rule__Coordinate__Group__2__Impl rule__Coordinate__Group__3 ;
    public final void rule__Coordinate__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:739:1: ( rule__Coordinate__Group__2__Impl rule__Coordinate__Group__3 )
            // InternalGameOfLifeDSL.g:740:2: rule__Coordinate__Group__2__Impl rule__Coordinate__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Coordinate__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__2"


    // $ANTLR start "rule__Coordinate__Group__2__Impl"
    // InternalGameOfLifeDSL.g:747:1: rule__Coordinate__Group__2__Impl : ( ',' ) ;
    public final void rule__Coordinate__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:751:1: ( ( ',' ) )
            // InternalGameOfLifeDSL.g:752:1: ( ',' )
            {
            // InternalGameOfLifeDSL.g:752:1: ( ',' )
            // InternalGameOfLifeDSL.g:753:2: ','
            {
             before(grammarAccess.getCoordinateAccess().getCommaKeyword_2()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getCoordinateAccess().getCommaKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__2__Impl"


    // $ANTLR start "rule__Coordinate__Group__3"
    // InternalGameOfLifeDSL.g:762:1: rule__Coordinate__Group__3 : rule__Coordinate__Group__3__Impl rule__Coordinate__Group__4 ;
    public final void rule__Coordinate__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:766:1: ( rule__Coordinate__Group__3__Impl rule__Coordinate__Group__4 )
            // InternalGameOfLifeDSL.g:767:2: rule__Coordinate__Group__3__Impl rule__Coordinate__Group__4
            {
            pushFollow(FOLLOW_10);
            rule__Coordinate__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__3"


    // $ANTLR start "rule__Coordinate__Group__3__Impl"
    // InternalGameOfLifeDSL.g:774:1: rule__Coordinate__Group__3__Impl : ( ( rule__Coordinate__YAssignment_3 ) ) ;
    public final void rule__Coordinate__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:778:1: ( ( ( rule__Coordinate__YAssignment_3 ) ) )
            // InternalGameOfLifeDSL.g:779:1: ( ( rule__Coordinate__YAssignment_3 ) )
            {
            // InternalGameOfLifeDSL.g:779:1: ( ( rule__Coordinate__YAssignment_3 ) )
            // InternalGameOfLifeDSL.g:780:2: ( rule__Coordinate__YAssignment_3 )
            {
             before(grammarAccess.getCoordinateAccess().getYAssignment_3()); 
            // InternalGameOfLifeDSL.g:781:2: ( rule__Coordinate__YAssignment_3 )
            // InternalGameOfLifeDSL.g:781:3: rule__Coordinate__YAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__YAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getYAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__3__Impl"


    // $ANTLR start "rule__Coordinate__Group__4"
    // InternalGameOfLifeDSL.g:789:1: rule__Coordinate__Group__4 : rule__Coordinate__Group__4__Impl ;
    public final void rule__Coordinate__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:793:1: ( rule__Coordinate__Group__4__Impl )
            // InternalGameOfLifeDSL.g:794:2: rule__Coordinate__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__4"


    // $ANTLR start "rule__Coordinate__Group__4__Impl"
    // InternalGameOfLifeDSL.g:800:1: rule__Coordinate__Group__4__Impl : ( ']' ) ;
    public final void rule__Coordinate__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:804:1: ( ( ']' ) )
            // InternalGameOfLifeDSL.g:805:1: ( ']' )
            {
            // InternalGameOfLifeDSL.g:805:1: ( ']' )
            // InternalGameOfLifeDSL.g:806:2: ']'
            {
             before(grammarAccess.getCoordinateAccess().getRightSquareBracketKeyword_4()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getCoordinateAccess().getRightSquareBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__4__Impl"


    // $ANTLR start "rule__GridSize__Group__0"
    // InternalGameOfLifeDSL.g:816:1: rule__GridSize__Group__0 : rule__GridSize__Group__0__Impl rule__GridSize__Group__1 ;
    public final void rule__GridSize__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:820:1: ( rule__GridSize__Group__0__Impl rule__GridSize__Group__1 )
            // InternalGameOfLifeDSL.g:821:2: rule__GridSize__Group__0__Impl rule__GridSize__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__GridSize__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GridSize__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__0"


    // $ANTLR start "rule__GridSize__Group__0__Impl"
    // InternalGameOfLifeDSL.g:828:1: rule__GridSize__Group__0__Impl : ( () ) ;
    public final void rule__GridSize__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:832:1: ( ( () ) )
            // InternalGameOfLifeDSL.g:833:1: ( () )
            {
            // InternalGameOfLifeDSL.g:833:1: ( () )
            // InternalGameOfLifeDSL.g:834:2: ()
            {
             before(grammarAccess.getGridSizeAccess().getGridSizeAction_0()); 
            // InternalGameOfLifeDSL.g:835:2: ()
            // InternalGameOfLifeDSL.g:835:3: 
            {
            }

             after(grammarAccess.getGridSizeAccess().getGridSizeAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__0__Impl"


    // $ANTLR start "rule__GridSize__Group__1"
    // InternalGameOfLifeDSL.g:843:1: rule__GridSize__Group__1 : rule__GridSize__Group__1__Impl rule__GridSize__Group__2 ;
    public final void rule__GridSize__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:847:1: ( rule__GridSize__Group__1__Impl rule__GridSize__Group__2 )
            // InternalGameOfLifeDSL.g:848:2: rule__GridSize__Group__1__Impl rule__GridSize__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__GridSize__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GridSize__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__1"


    // $ANTLR start "rule__GridSize__Group__1__Impl"
    // InternalGameOfLifeDSL.g:855:1: rule__GridSize__Group__1__Impl : ( 'GridSize' ) ;
    public final void rule__GridSize__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:859:1: ( ( 'GridSize' ) )
            // InternalGameOfLifeDSL.g:860:1: ( 'GridSize' )
            {
            // InternalGameOfLifeDSL.g:860:1: ( 'GridSize' )
            // InternalGameOfLifeDSL.g:861:2: 'GridSize'
            {
             before(grammarAccess.getGridSizeAccess().getGridSizeKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getGridSizeAccess().getGridSizeKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__1__Impl"


    // $ANTLR start "rule__GridSize__Group__2"
    // InternalGameOfLifeDSL.g:870:1: rule__GridSize__Group__2 : rule__GridSize__Group__2__Impl rule__GridSize__Group__3 ;
    public final void rule__GridSize__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:874:1: ( rule__GridSize__Group__2__Impl rule__GridSize__Group__3 )
            // InternalGameOfLifeDSL.g:875:2: rule__GridSize__Group__2__Impl rule__GridSize__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__GridSize__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GridSize__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__2"


    // $ANTLR start "rule__GridSize__Group__2__Impl"
    // InternalGameOfLifeDSL.g:882:1: rule__GridSize__Group__2__Impl : ( '=' ) ;
    public final void rule__GridSize__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:886:1: ( ( '=' ) )
            // InternalGameOfLifeDSL.g:887:1: ( '=' )
            {
            // InternalGameOfLifeDSL.g:887:1: ( '=' )
            // InternalGameOfLifeDSL.g:888:2: '='
            {
             before(grammarAccess.getGridSizeAccess().getEqualsSignKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGridSizeAccess().getEqualsSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__2__Impl"


    // $ANTLR start "rule__GridSize__Group__3"
    // InternalGameOfLifeDSL.g:897:1: rule__GridSize__Group__3 : rule__GridSize__Group__3__Impl ;
    public final void rule__GridSize__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:901:1: ( rule__GridSize__Group__3__Impl )
            // InternalGameOfLifeDSL.g:902:2: rule__GridSize__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GridSize__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__3"


    // $ANTLR start "rule__GridSize__Group__3__Impl"
    // InternalGameOfLifeDSL.g:908:1: rule__GridSize__Group__3__Impl : ( ( rule__GridSize__GridNumAssignment_3 ) ) ;
    public final void rule__GridSize__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:912:1: ( ( ( rule__GridSize__GridNumAssignment_3 ) ) )
            // InternalGameOfLifeDSL.g:913:1: ( ( rule__GridSize__GridNumAssignment_3 ) )
            {
            // InternalGameOfLifeDSL.g:913:1: ( ( rule__GridSize__GridNumAssignment_3 ) )
            // InternalGameOfLifeDSL.g:914:2: ( rule__GridSize__GridNumAssignment_3 )
            {
             before(grammarAccess.getGridSizeAccess().getGridNumAssignment_3()); 
            // InternalGameOfLifeDSL.g:915:2: ( rule__GridSize__GridNumAssignment_3 )
            // InternalGameOfLifeDSL.g:915:3: rule__GridSize__GridNumAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__GridSize__GridNumAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getGridSizeAccess().getGridNumAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__Group__3__Impl"


    // $ANTLR start "rule__Initial__Group__0"
    // InternalGameOfLifeDSL.g:924:1: rule__Initial__Group__0 : rule__Initial__Group__0__Impl rule__Initial__Group__1 ;
    public final void rule__Initial__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:928:1: ( rule__Initial__Group__0__Impl rule__Initial__Group__1 )
            // InternalGameOfLifeDSL.g:929:2: rule__Initial__Group__0__Impl rule__Initial__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Initial__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Initial__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__0"


    // $ANTLR start "rule__Initial__Group__0__Impl"
    // InternalGameOfLifeDSL.g:936:1: rule__Initial__Group__0__Impl : ( () ) ;
    public final void rule__Initial__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:940:1: ( ( () ) )
            // InternalGameOfLifeDSL.g:941:1: ( () )
            {
            // InternalGameOfLifeDSL.g:941:1: ( () )
            // InternalGameOfLifeDSL.g:942:2: ()
            {
             before(grammarAccess.getInitialAccess().getInitialAction_0()); 
            // InternalGameOfLifeDSL.g:943:2: ()
            // InternalGameOfLifeDSL.g:943:3: 
            {
            }

             after(grammarAccess.getInitialAccess().getInitialAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__0__Impl"


    // $ANTLR start "rule__Initial__Group__1"
    // InternalGameOfLifeDSL.g:951:1: rule__Initial__Group__1 : rule__Initial__Group__1__Impl rule__Initial__Group__2 ;
    public final void rule__Initial__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:955:1: ( rule__Initial__Group__1__Impl rule__Initial__Group__2 )
            // InternalGameOfLifeDSL.g:956:2: rule__Initial__Group__1__Impl rule__Initial__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__Initial__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Initial__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__1"


    // $ANTLR start "rule__Initial__Group__1__Impl"
    // InternalGameOfLifeDSL.g:963:1: rule__Initial__Group__1__Impl : ( 'Initial:' ) ;
    public final void rule__Initial__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:967:1: ( ( 'Initial:' ) )
            // InternalGameOfLifeDSL.g:968:1: ( 'Initial:' )
            {
            // InternalGameOfLifeDSL.g:968:1: ( 'Initial:' )
            // InternalGameOfLifeDSL.g:969:2: 'Initial:'
            {
             before(grammarAccess.getInitialAccess().getInitialKeyword_1()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getInitialAccess().getInitialKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__1__Impl"


    // $ANTLR start "rule__Initial__Group__2"
    // InternalGameOfLifeDSL.g:978:1: rule__Initial__Group__2 : rule__Initial__Group__2__Impl rule__Initial__Group__3 ;
    public final void rule__Initial__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:982:1: ( rule__Initial__Group__2__Impl rule__Initial__Group__3 )
            // InternalGameOfLifeDSL.g:983:2: rule__Initial__Group__2__Impl rule__Initial__Group__3
            {
            pushFollow(FOLLOW_13);
            rule__Initial__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Initial__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__2"


    // $ANTLR start "rule__Initial__Group__2__Impl"
    // InternalGameOfLifeDSL.g:990:1: rule__Initial__Group__2__Impl : ( ( rule__Initial__CoordinatesAssignment_2 )? ) ;
    public final void rule__Initial__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:994:1: ( ( ( rule__Initial__CoordinatesAssignment_2 )? ) )
            // InternalGameOfLifeDSL.g:995:1: ( ( rule__Initial__CoordinatesAssignment_2 )? )
            {
            // InternalGameOfLifeDSL.g:995:1: ( ( rule__Initial__CoordinatesAssignment_2 )? )
            // InternalGameOfLifeDSL.g:996:2: ( rule__Initial__CoordinatesAssignment_2 )?
            {
             before(grammarAccess.getInitialAccess().getCoordinatesAssignment_2()); 
            // InternalGameOfLifeDSL.g:997:2: ( rule__Initial__CoordinatesAssignment_2 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==15) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalGameOfLifeDSL.g:997:3: rule__Initial__CoordinatesAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Initial__CoordinatesAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getInitialAccess().getCoordinatesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__2__Impl"


    // $ANTLR start "rule__Initial__Group__3"
    // InternalGameOfLifeDSL.g:1005:1: rule__Initial__Group__3 : rule__Initial__Group__3__Impl ;
    public final void rule__Initial__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1009:1: ( rule__Initial__Group__3__Impl )
            // InternalGameOfLifeDSL.g:1010:2: rule__Initial__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Initial__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__3"


    // $ANTLR start "rule__Initial__Group__3__Impl"
    // InternalGameOfLifeDSL.g:1016:1: rule__Initial__Group__3__Impl : ( ( rule__Initial__Group_3__0 )? ) ;
    public final void rule__Initial__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1020:1: ( ( ( rule__Initial__Group_3__0 )? ) )
            // InternalGameOfLifeDSL.g:1021:1: ( ( rule__Initial__Group_3__0 )? )
            {
            // InternalGameOfLifeDSL.g:1021:1: ( ( rule__Initial__Group_3__0 )? )
            // InternalGameOfLifeDSL.g:1022:2: ( rule__Initial__Group_3__0 )?
            {
             before(grammarAccess.getInitialAccess().getGroup_3()); 
            // InternalGameOfLifeDSL.g:1023:2: ( rule__Initial__Group_3__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalGameOfLifeDSL.g:1023:3: rule__Initial__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Initial__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getInitialAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group__3__Impl"


    // $ANTLR start "rule__Initial__Group_3__0"
    // InternalGameOfLifeDSL.g:1032:1: rule__Initial__Group_3__0 : rule__Initial__Group_3__0__Impl rule__Initial__Group_3__1 ;
    public final void rule__Initial__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1036:1: ( rule__Initial__Group_3__0__Impl rule__Initial__Group_3__1 )
            // InternalGameOfLifeDSL.g:1037:2: rule__Initial__Group_3__0__Impl rule__Initial__Group_3__1
            {
            pushFollow(FOLLOW_6);
            rule__Initial__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Initial__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group_3__0"


    // $ANTLR start "rule__Initial__Group_3__0__Impl"
    // InternalGameOfLifeDSL.g:1044:1: rule__Initial__Group_3__0__Impl : ( 'Patterns:' ) ;
    public final void rule__Initial__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1048:1: ( ( 'Patterns:' ) )
            // InternalGameOfLifeDSL.g:1049:1: ( 'Patterns:' )
            {
            // InternalGameOfLifeDSL.g:1049:1: ( 'Patterns:' )
            // InternalGameOfLifeDSL.g:1050:2: 'Patterns:'
            {
             before(grammarAccess.getInitialAccess().getPatternsKeyword_3_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getInitialAccess().getPatternsKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group_3__0__Impl"


    // $ANTLR start "rule__Initial__Group_3__1"
    // InternalGameOfLifeDSL.g:1059:1: rule__Initial__Group_3__1 : rule__Initial__Group_3__1__Impl ;
    public final void rule__Initial__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1063:1: ( rule__Initial__Group_3__1__Impl )
            // InternalGameOfLifeDSL.g:1064:2: rule__Initial__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Initial__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group_3__1"


    // $ANTLR start "rule__Initial__Group_3__1__Impl"
    // InternalGameOfLifeDSL.g:1070:1: rule__Initial__Group_3__1__Impl : ( ( rule__Initial__PatternsAssignment_3_1 )* ) ;
    public final void rule__Initial__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1074:1: ( ( ( rule__Initial__PatternsAssignment_3_1 )* ) )
            // InternalGameOfLifeDSL.g:1075:1: ( ( rule__Initial__PatternsAssignment_3_1 )* )
            {
            // InternalGameOfLifeDSL.g:1075:1: ( ( rule__Initial__PatternsAssignment_3_1 )* )
            // InternalGameOfLifeDSL.g:1076:2: ( rule__Initial__PatternsAssignment_3_1 )*
            {
             before(grammarAccess.getInitialAccess().getPatternsAssignment_3_1()); 
            // InternalGameOfLifeDSL.g:1077:2: ( rule__Initial__PatternsAssignment_3_1 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==17) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalGameOfLifeDSL.g:1077:3: rule__Initial__PatternsAssignment_3_1
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Initial__PatternsAssignment_3_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getInitialAccess().getPatternsAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__Group_3__1__Impl"


    // $ANTLR start "rule__PatternRLE__Group__0"
    // InternalGameOfLifeDSL.g:1086:1: rule__PatternRLE__Group__0 : rule__PatternRLE__Group__0__Impl rule__PatternRLE__Group__1 ;
    public final void rule__PatternRLE__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1090:1: ( rule__PatternRLE__Group__0__Impl rule__PatternRLE__Group__1 )
            // InternalGameOfLifeDSL.g:1091:2: rule__PatternRLE__Group__0__Impl rule__PatternRLE__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__PatternRLE__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PatternRLE__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__Group__0"


    // $ANTLR start "rule__PatternRLE__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1098:1: rule__PatternRLE__Group__0__Impl : ( ( rule__PatternRLE__StartAssignment_0 ) ) ;
    public final void rule__PatternRLE__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1102:1: ( ( ( rule__PatternRLE__StartAssignment_0 ) ) )
            // InternalGameOfLifeDSL.g:1103:1: ( ( rule__PatternRLE__StartAssignment_0 ) )
            {
            // InternalGameOfLifeDSL.g:1103:1: ( ( rule__PatternRLE__StartAssignment_0 ) )
            // InternalGameOfLifeDSL.g:1104:2: ( rule__PatternRLE__StartAssignment_0 )
            {
             before(grammarAccess.getPatternRLEAccess().getStartAssignment_0()); 
            // InternalGameOfLifeDSL.g:1105:2: ( rule__PatternRLE__StartAssignment_0 )
            // InternalGameOfLifeDSL.g:1105:3: rule__PatternRLE__StartAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__PatternRLE__StartAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPatternRLEAccess().getStartAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__Group__0__Impl"


    // $ANTLR start "rule__PatternRLE__Group__1"
    // InternalGameOfLifeDSL.g:1113:1: rule__PatternRLE__Group__1 : rule__PatternRLE__Group__1__Impl ;
    public final void rule__PatternRLE__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1117:1: ( rule__PatternRLE__Group__1__Impl )
            // InternalGameOfLifeDSL.g:1118:2: rule__PatternRLE__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PatternRLE__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__Group__1"


    // $ANTLR start "rule__PatternRLE__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1124:1: rule__PatternRLE__Group__1__Impl : ( ( rule__PatternRLE__PatternAssignment_1 ) ) ;
    public final void rule__PatternRLE__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1128:1: ( ( ( rule__PatternRLE__PatternAssignment_1 ) ) )
            // InternalGameOfLifeDSL.g:1129:1: ( ( rule__PatternRLE__PatternAssignment_1 ) )
            {
            // InternalGameOfLifeDSL.g:1129:1: ( ( rule__PatternRLE__PatternAssignment_1 ) )
            // InternalGameOfLifeDSL.g:1130:2: ( rule__PatternRLE__PatternAssignment_1 )
            {
             before(grammarAccess.getPatternRLEAccess().getPatternAssignment_1()); 
            // InternalGameOfLifeDSL.g:1131:2: ( rule__PatternRLE__PatternAssignment_1 )
            // InternalGameOfLifeDSL.g:1131:3: rule__PatternRLE__PatternAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PatternRLE__PatternAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPatternRLEAccess().getPatternAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__Group__1__Impl"


    // $ANTLR start "rule__Grid__Group__0"
    // InternalGameOfLifeDSL.g:1140:1: rule__Grid__Group__0 : rule__Grid__Group__0__Impl rule__Grid__Group__1 ;
    public final void rule__Grid__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1144:1: ( rule__Grid__Group__0__Impl rule__Grid__Group__1 )
            // InternalGameOfLifeDSL.g:1145:2: rule__Grid__Group__0__Impl rule__Grid__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Grid__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Grid__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__0"


    // $ANTLR start "rule__Grid__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1152:1: rule__Grid__Group__0__Impl : ( '[' ) ;
    public final void rule__Grid__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1156:1: ( ( '[' ) )
            // InternalGameOfLifeDSL.g:1157:1: ( '[' )
            {
            // InternalGameOfLifeDSL.g:1157:1: ( '[' )
            // InternalGameOfLifeDSL.g:1158:2: '['
            {
             before(grammarAccess.getGridAccess().getLeftSquareBracketKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGridAccess().getLeftSquareBracketKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__0__Impl"


    // $ANTLR start "rule__Grid__Group__1"
    // InternalGameOfLifeDSL.g:1167:1: rule__Grid__Group__1 : rule__Grid__Group__1__Impl rule__Grid__Group__2 ;
    public final void rule__Grid__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1171:1: ( rule__Grid__Group__1__Impl rule__Grid__Group__2 )
            // InternalGameOfLifeDSL.g:1172:2: rule__Grid__Group__1__Impl rule__Grid__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Grid__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Grid__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__1"


    // $ANTLR start "rule__Grid__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1179:1: rule__Grid__Group__1__Impl : ( ( rule__Grid__XAssignment_1 ) ) ;
    public final void rule__Grid__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1183:1: ( ( ( rule__Grid__XAssignment_1 ) ) )
            // InternalGameOfLifeDSL.g:1184:1: ( ( rule__Grid__XAssignment_1 ) )
            {
            // InternalGameOfLifeDSL.g:1184:1: ( ( rule__Grid__XAssignment_1 ) )
            // InternalGameOfLifeDSL.g:1185:2: ( rule__Grid__XAssignment_1 )
            {
             before(grammarAccess.getGridAccess().getXAssignment_1()); 
            // InternalGameOfLifeDSL.g:1186:2: ( rule__Grid__XAssignment_1 )
            // InternalGameOfLifeDSL.g:1186:3: rule__Grid__XAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Grid__XAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGridAccess().getXAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__1__Impl"


    // $ANTLR start "rule__Grid__Group__2"
    // InternalGameOfLifeDSL.g:1194:1: rule__Grid__Group__2 : rule__Grid__Group__2__Impl rule__Grid__Group__3 ;
    public final void rule__Grid__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1198:1: ( rule__Grid__Group__2__Impl rule__Grid__Group__3 )
            // InternalGameOfLifeDSL.g:1199:2: rule__Grid__Group__2__Impl rule__Grid__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Grid__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Grid__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__2"


    // $ANTLR start "rule__Grid__Group__2__Impl"
    // InternalGameOfLifeDSL.g:1206:1: rule__Grid__Group__2__Impl : ( 'x' ) ;
    public final void rule__Grid__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1210:1: ( ( 'x' ) )
            // InternalGameOfLifeDSL.g:1211:1: ( 'x' )
            {
            // InternalGameOfLifeDSL.g:1211:1: ( 'x' )
            // InternalGameOfLifeDSL.g:1212:2: 'x'
            {
             before(grammarAccess.getGridAccess().getXKeyword_2()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getGridAccess().getXKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__2__Impl"


    // $ANTLR start "rule__Grid__Group__3"
    // InternalGameOfLifeDSL.g:1221:1: rule__Grid__Group__3 : rule__Grid__Group__3__Impl rule__Grid__Group__4 ;
    public final void rule__Grid__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1225:1: ( rule__Grid__Group__3__Impl rule__Grid__Group__4 )
            // InternalGameOfLifeDSL.g:1226:2: rule__Grid__Group__3__Impl rule__Grid__Group__4
            {
            pushFollow(FOLLOW_10);
            rule__Grid__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Grid__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__3"


    // $ANTLR start "rule__Grid__Group__3__Impl"
    // InternalGameOfLifeDSL.g:1233:1: rule__Grid__Group__3__Impl : ( ( rule__Grid__YAssignment_3 ) ) ;
    public final void rule__Grid__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1237:1: ( ( ( rule__Grid__YAssignment_3 ) ) )
            // InternalGameOfLifeDSL.g:1238:1: ( ( rule__Grid__YAssignment_3 ) )
            {
            // InternalGameOfLifeDSL.g:1238:1: ( ( rule__Grid__YAssignment_3 ) )
            // InternalGameOfLifeDSL.g:1239:2: ( rule__Grid__YAssignment_3 )
            {
             before(grammarAccess.getGridAccess().getYAssignment_3()); 
            // InternalGameOfLifeDSL.g:1240:2: ( rule__Grid__YAssignment_3 )
            // InternalGameOfLifeDSL.g:1240:3: rule__Grid__YAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Grid__YAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getGridAccess().getYAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__3__Impl"


    // $ANTLR start "rule__Grid__Group__4"
    // InternalGameOfLifeDSL.g:1248:1: rule__Grid__Group__4 : rule__Grid__Group__4__Impl ;
    public final void rule__Grid__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1252:1: ( rule__Grid__Group__4__Impl )
            // InternalGameOfLifeDSL.g:1253:2: rule__Grid__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Grid__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__4"


    // $ANTLR start "rule__Grid__Group__4__Impl"
    // InternalGameOfLifeDSL.g:1259:1: rule__Grid__Group__4__Impl : ( ']' ) ;
    public final void rule__Grid__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1263:1: ( ( ']' ) )
            // InternalGameOfLifeDSL.g:1264:1: ( ']' )
            {
            // InternalGameOfLifeDSL.g:1264:1: ( ']' )
            // InternalGameOfLifeDSL.g:1265:2: ']'
            {
             before(grammarAccess.getGridAccess().getRightSquareBracketKeyword_4()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGridAccess().getRightSquareBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__Group__4__Impl"


    // $ANTLR start "rule__Rules__Group__0"
    // InternalGameOfLifeDSL.g:1275:1: rule__Rules__Group__0 : rule__Rules__Group__0__Impl rule__Rules__Group__1 ;
    public final void rule__Rules__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1279:1: ( rule__Rules__Group__0__Impl rule__Rules__Group__1 )
            // InternalGameOfLifeDSL.g:1280:2: rule__Rules__Group__0__Impl rule__Rules__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Rules__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rules__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__0"


    // $ANTLR start "rule__Rules__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1287:1: rule__Rules__Group__0__Impl : ( () ) ;
    public final void rule__Rules__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1291:1: ( ( () ) )
            // InternalGameOfLifeDSL.g:1292:1: ( () )
            {
            // InternalGameOfLifeDSL.g:1292:1: ( () )
            // InternalGameOfLifeDSL.g:1293:2: ()
            {
             before(grammarAccess.getRulesAccess().getRulesAction_0()); 
            // InternalGameOfLifeDSL.g:1294:2: ()
            // InternalGameOfLifeDSL.g:1294:3: 
            {
            }

             after(grammarAccess.getRulesAccess().getRulesAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__0__Impl"


    // $ANTLR start "rule__Rules__Group__1"
    // InternalGameOfLifeDSL.g:1302:1: rule__Rules__Group__1 : rule__Rules__Group__1__Impl rule__Rules__Group__2 ;
    public final void rule__Rules__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1306:1: ( rule__Rules__Group__1__Impl rule__Rules__Group__2 )
            // InternalGameOfLifeDSL.g:1307:2: rule__Rules__Group__1__Impl rule__Rules__Group__2
            {
            pushFollow(FOLLOW_16);
            rule__Rules__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rules__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__1"


    // $ANTLR start "rule__Rules__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1314:1: rule__Rules__Group__1__Impl : ( 'Rules:' ) ;
    public final void rule__Rules__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1318:1: ( ( 'Rules:' ) )
            // InternalGameOfLifeDSL.g:1319:1: ( 'Rules:' )
            {
            // InternalGameOfLifeDSL.g:1319:1: ( 'Rules:' )
            // InternalGameOfLifeDSL.g:1320:2: 'Rules:'
            {
             before(grammarAccess.getRulesAccess().getRulesKeyword_1()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getRulesAccess().getRulesKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__1__Impl"


    // $ANTLR start "rule__Rules__Group__2"
    // InternalGameOfLifeDSL.g:1329:1: rule__Rules__Group__2 : rule__Rules__Group__2__Impl rule__Rules__Group__3 ;
    public final void rule__Rules__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1333:1: ( rule__Rules__Group__2__Impl rule__Rules__Group__3 )
            // InternalGameOfLifeDSL.g:1334:2: rule__Rules__Group__2__Impl rule__Rules__Group__3
            {
            pushFollow(FOLLOW_16);
            rule__Rules__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rules__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__2"


    // $ANTLR start "rule__Rules__Group__2__Impl"
    // InternalGameOfLifeDSL.g:1341:1: rule__Rules__Group__2__Impl : ( ( rule__Rules__Group_2__0 )? ) ;
    public final void rule__Rules__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1345:1: ( ( ( rule__Rules__Group_2__0 )? ) )
            // InternalGameOfLifeDSL.g:1346:1: ( ( rule__Rules__Group_2__0 )? )
            {
            // InternalGameOfLifeDSL.g:1346:1: ( ( rule__Rules__Group_2__0 )? )
            // InternalGameOfLifeDSL.g:1347:2: ( rule__Rules__Group_2__0 )?
            {
             before(grammarAccess.getRulesAccess().getGroup_2()); 
            // InternalGameOfLifeDSL.g:1348:2: ( rule__Rules__Group_2__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==25) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalGameOfLifeDSL.g:1348:3: rule__Rules__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Rules__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRulesAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__2__Impl"


    // $ANTLR start "rule__Rules__Group__3"
    // InternalGameOfLifeDSL.g:1356:1: rule__Rules__Group__3 : rule__Rules__Group__3__Impl ;
    public final void rule__Rules__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1360:1: ( rule__Rules__Group__3__Impl )
            // InternalGameOfLifeDSL.g:1361:2: rule__Rules__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Rules__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__3"


    // $ANTLR start "rule__Rules__Group__3__Impl"
    // InternalGameOfLifeDSL.g:1367:1: rule__Rules__Group__3__Impl : ( ( rule__Rules__RulesAssignment_3 )* ) ;
    public final void rule__Rules__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1371:1: ( ( ( rule__Rules__RulesAssignment_3 )* ) )
            // InternalGameOfLifeDSL.g:1372:1: ( ( rule__Rules__RulesAssignment_3 )* )
            {
            // InternalGameOfLifeDSL.g:1372:1: ( ( rule__Rules__RulesAssignment_3 )* )
            // InternalGameOfLifeDSL.g:1373:2: ( rule__Rules__RulesAssignment_3 )*
            {
             before(grammarAccess.getRulesAccess().getRulesAssignment_3()); 
            // InternalGameOfLifeDSL.g:1374:2: ( rule__Rules__RulesAssignment_3 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=12 && LA12_0<=14)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalGameOfLifeDSL.g:1374:3: rule__Rules__RulesAssignment_3
            	    {
            	    pushFollow(FOLLOW_17);
            	    rule__Rules__RulesAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getRulesAccess().getRulesAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group__3__Impl"


    // $ANTLR start "rule__Rules__Group_2__0"
    // InternalGameOfLifeDSL.g:1383:1: rule__Rules__Group_2__0 : rule__Rules__Group_2__0__Impl rule__Rules__Group_2__1 ;
    public final void rule__Rules__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1387:1: ( rule__Rules__Group_2__0__Impl rule__Rules__Group_2__1 )
            // InternalGameOfLifeDSL.g:1388:2: rule__Rules__Group_2__0__Impl rule__Rules__Group_2__1
            {
            pushFollow(FOLLOW_18);
            rule__Rules__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rules__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group_2__0"


    // $ANTLR start "rule__Rules__Group_2__0__Impl"
    // InternalGameOfLifeDSL.g:1395:1: rule__Rules__Group_2__0__Impl : ( 'default:' ) ;
    public final void rule__Rules__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1399:1: ( ( 'default:' ) )
            // InternalGameOfLifeDSL.g:1400:1: ( 'default:' )
            {
            // InternalGameOfLifeDSL.g:1400:1: ( 'default:' )
            // InternalGameOfLifeDSL.g:1401:2: 'default:'
            {
             before(grammarAccess.getRulesAccess().getDefaultKeyword_2_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getRulesAccess().getDefaultKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group_2__0__Impl"


    // $ANTLR start "rule__Rules__Group_2__1"
    // InternalGameOfLifeDSL.g:1410:1: rule__Rules__Group_2__1 : rule__Rules__Group_2__1__Impl ;
    public final void rule__Rules__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1414:1: ( rule__Rules__Group_2__1__Impl )
            // InternalGameOfLifeDSL.g:1415:2: rule__Rules__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Rules__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group_2__1"


    // $ANTLR start "rule__Rules__Group_2__1__Impl"
    // InternalGameOfLifeDSL.g:1421:1: rule__Rules__Group_2__1__Impl : ( ( rule__Rules__DefaultConsequenceAssignment_2_1 ) ) ;
    public final void rule__Rules__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1425:1: ( ( ( rule__Rules__DefaultConsequenceAssignment_2_1 ) ) )
            // InternalGameOfLifeDSL.g:1426:1: ( ( rule__Rules__DefaultConsequenceAssignment_2_1 ) )
            {
            // InternalGameOfLifeDSL.g:1426:1: ( ( rule__Rules__DefaultConsequenceAssignment_2_1 ) )
            // InternalGameOfLifeDSL.g:1427:2: ( rule__Rules__DefaultConsequenceAssignment_2_1 )
            {
             before(grammarAccess.getRulesAccess().getDefaultConsequenceAssignment_2_1()); 
            // InternalGameOfLifeDSL.g:1428:2: ( rule__Rules__DefaultConsequenceAssignment_2_1 )
            // InternalGameOfLifeDSL.g:1428:3: rule__Rules__DefaultConsequenceAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Rules__DefaultConsequenceAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getRulesAccess().getDefaultConsequenceAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__Group_2__1__Impl"


    // $ANTLR start "rule__Rule__Group__0"
    // InternalGameOfLifeDSL.g:1437:1: rule__Rule__Group__0 : rule__Rule__Group__0__Impl rule__Rule__Group__1 ;
    public final void rule__Rule__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1441:1: ( rule__Rule__Group__0__Impl rule__Rule__Group__1 )
            // InternalGameOfLifeDSL.g:1442:2: rule__Rule__Group__0__Impl rule__Rule__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__Rule__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rule__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__0"


    // $ANTLR start "rule__Rule__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1449:1: rule__Rule__Group__0__Impl : ( ( rule__Rule__ConsequenceAssignment_0 ) ) ;
    public final void rule__Rule__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1453:1: ( ( ( rule__Rule__ConsequenceAssignment_0 ) ) )
            // InternalGameOfLifeDSL.g:1454:1: ( ( rule__Rule__ConsequenceAssignment_0 ) )
            {
            // InternalGameOfLifeDSL.g:1454:1: ( ( rule__Rule__ConsequenceAssignment_0 ) )
            // InternalGameOfLifeDSL.g:1455:2: ( rule__Rule__ConsequenceAssignment_0 )
            {
             before(grammarAccess.getRuleAccess().getConsequenceAssignment_0()); 
            // InternalGameOfLifeDSL.g:1456:2: ( rule__Rule__ConsequenceAssignment_0 )
            // InternalGameOfLifeDSL.g:1456:3: rule__Rule__ConsequenceAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Rule__ConsequenceAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getConsequenceAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__0__Impl"


    // $ANTLR start "rule__Rule__Group__1"
    // InternalGameOfLifeDSL.g:1464:1: rule__Rule__Group__1 : rule__Rule__Group__1__Impl ;
    public final void rule__Rule__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1468:1: ( rule__Rule__Group__1__Impl )
            // InternalGameOfLifeDSL.g:1469:2: rule__Rule__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Rule__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__1"


    // $ANTLR start "rule__Rule__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1475:1: rule__Rule__Group__1__Impl : ( ( rule__Rule__ReasonAssignment_1 ) ) ;
    public final void rule__Rule__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1479:1: ( ( ( rule__Rule__ReasonAssignment_1 ) ) )
            // InternalGameOfLifeDSL.g:1480:1: ( ( rule__Rule__ReasonAssignment_1 ) )
            {
            // InternalGameOfLifeDSL.g:1480:1: ( ( rule__Rule__ReasonAssignment_1 ) )
            // InternalGameOfLifeDSL.g:1481:2: ( rule__Rule__ReasonAssignment_1 )
            {
             before(grammarAccess.getRuleAccess().getReasonAssignment_1()); 
            // InternalGameOfLifeDSL.g:1482:2: ( rule__Rule__ReasonAssignment_1 )
            // InternalGameOfLifeDSL.g:1482:3: rule__Rule__ReasonAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Rule__ReasonAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getReasonAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__1__Impl"


    // $ANTLR start "rule__Reason__Group__0"
    // InternalGameOfLifeDSL.g:1491:1: rule__Reason__Group__0 : rule__Reason__Group__0__Impl rule__Reason__Group__1 ;
    public final void rule__Reason__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1495:1: ( rule__Reason__Group__0__Impl rule__Reason__Group__1 )
            // InternalGameOfLifeDSL.g:1496:2: rule__Reason__Group__0__Impl rule__Reason__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__Reason__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reason__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__0"


    // $ANTLR start "rule__Reason__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1503:1: rule__Reason__Group__0__Impl : ( 'if' ) ;
    public final void rule__Reason__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1507:1: ( ( 'if' ) )
            // InternalGameOfLifeDSL.g:1508:1: ( 'if' )
            {
            // InternalGameOfLifeDSL.g:1508:1: ( 'if' )
            // InternalGameOfLifeDSL.g:1509:2: 'if'
            {
             before(grammarAccess.getReasonAccess().getIfKeyword_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getReasonAccess().getIfKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__0__Impl"


    // $ANTLR start "rule__Reason__Group__1"
    // InternalGameOfLifeDSL.g:1518:1: rule__Reason__Group__1 : rule__Reason__Group__1__Impl rule__Reason__Group__2 ;
    public final void rule__Reason__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1522:1: ( rule__Reason__Group__1__Impl rule__Reason__Group__2 )
            // InternalGameOfLifeDSL.g:1523:2: rule__Reason__Group__1__Impl rule__Reason__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__Reason__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reason__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__1"


    // $ANTLR start "rule__Reason__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1530:1: rule__Reason__Group__1__Impl : ( '[' ) ;
    public final void rule__Reason__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1534:1: ( ( '[' ) )
            // InternalGameOfLifeDSL.g:1535:1: ( '[' )
            {
            // InternalGameOfLifeDSL.g:1535:1: ( '[' )
            // InternalGameOfLifeDSL.g:1536:2: '['
            {
             before(grammarAccess.getReasonAccess().getLeftSquareBracketKeyword_1()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getReasonAccess().getLeftSquareBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__1__Impl"


    // $ANTLR start "rule__Reason__Group__2"
    // InternalGameOfLifeDSL.g:1545:1: rule__Reason__Group__2 : rule__Reason__Group__2__Impl rule__Reason__Group__3 ;
    public final void rule__Reason__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1549:1: ( rule__Reason__Group__2__Impl rule__Reason__Group__3 )
            // InternalGameOfLifeDSL.g:1550:2: rule__Reason__Group__2__Impl rule__Reason__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Reason__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reason__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__2"


    // $ANTLR start "rule__Reason__Group__2__Impl"
    // InternalGameOfLifeDSL.g:1557:1: rule__Reason__Group__2__Impl : ( ( rule__Reason__ConditionAssignment_2 ) ) ;
    public final void rule__Reason__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1561:1: ( ( ( rule__Reason__ConditionAssignment_2 ) ) )
            // InternalGameOfLifeDSL.g:1562:1: ( ( rule__Reason__ConditionAssignment_2 ) )
            {
            // InternalGameOfLifeDSL.g:1562:1: ( ( rule__Reason__ConditionAssignment_2 ) )
            // InternalGameOfLifeDSL.g:1563:2: ( rule__Reason__ConditionAssignment_2 )
            {
             before(grammarAccess.getReasonAccess().getConditionAssignment_2()); 
            // InternalGameOfLifeDSL.g:1564:2: ( rule__Reason__ConditionAssignment_2 )
            // InternalGameOfLifeDSL.g:1564:3: rule__Reason__ConditionAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Reason__ConditionAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getReasonAccess().getConditionAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__2__Impl"


    // $ANTLR start "rule__Reason__Group__3"
    // InternalGameOfLifeDSL.g:1572:1: rule__Reason__Group__3 : rule__Reason__Group__3__Impl rule__Reason__Group__4 ;
    public final void rule__Reason__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1576:1: ( rule__Reason__Group__3__Impl rule__Reason__Group__4 )
            // InternalGameOfLifeDSL.g:1577:2: rule__Reason__Group__3__Impl rule__Reason__Group__4
            {
            pushFollow(FOLLOW_21);
            rule__Reason__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reason__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__3"


    // $ANTLR start "rule__Reason__Group__3__Impl"
    // InternalGameOfLifeDSL.g:1584:1: rule__Reason__Group__3__Impl : ( ']' ) ;
    public final void rule__Reason__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1588:1: ( ( ']' ) )
            // InternalGameOfLifeDSL.g:1589:1: ( ']' )
            {
            // InternalGameOfLifeDSL.g:1589:1: ( ']' )
            // InternalGameOfLifeDSL.g:1590:2: ']'
            {
             before(grammarAccess.getReasonAccess().getRightSquareBracketKeyword_3()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getReasonAccess().getRightSquareBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__3__Impl"


    // $ANTLR start "rule__Reason__Group__4"
    // InternalGameOfLifeDSL.g:1599:1: rule__Reason__Group__4 : rule__Reason__Group__4__Impl ;
    public final void rule__Reason__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1603:1: ( rule__Reason__Group__4__Impl )
            // InternalGameOfLifeDSL.g:1604:2: rule__Reason__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Reason__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__4"


    // $ANTLR start "rule__Reason__Group__4__Impl"
    // InternalGameOfLifeDSL.g:1610:1: rule__Reason__Group__4__Impl : ( 'companions' ) ;
    public final void rule__Reason__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1614:1: ( ( 'companions' ) )
            // InternalGameOfLifeDSL.g:1615:1: ( 'companions' )
            {
            // InternalGameOfLifeDSL.g:1615:1: ( 'companions' )
            // InternalGameOfLifeDSL.g:1616:2: 'companions'
            {
             before(grammarAccess.getReasonAccess().getCompanionsKeyword_4()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getReasonAccess().getCompanionsKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__Group__4__Impl"


    // $ANTLR start "rule__Condition__Group__0"
    // InternalGameOfLifeDSL.g:1626:1: rule__Condition__Group__0 : rule__Condition__Group__0__Impl rule__Condition__Group__1 ;
    public final void rule__Condition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1630:1: ( rule__Condition__Group__0__Impl rule__Condition__Group__1 )
            // InternalGameOfLifeDSL.g:1631:2: rule__Condition__Group__0__Impl rule__Condition__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Condition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__0"


    // $ANTLR start "rule__Condition__Group__0__Impl"
    // InternalGameOfLifeDSL.g:1638:1: rule__Condition__Group__0__Impl : ( ( rule__Condition__OperatorAssignment_0 ) ) ;
    public final void rule__Condition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1642:1: ( ( ( rule__Condition__OperatorAssignment_0 ) ) )
            // InternalGameOfLifeDSL.g:1643:1: ( ( rule__Condition__OperatorAssignment_0 ) )
            {
            // InternalGameOfLifeDSL.g:1643:1: ( ( rule__Condition__OperatorAssignment_0 ) )
            // InternalGameOfLifeDSL.g:1644:2: ( rule__Condition__OperatorAssignment_0 )
            {
             before(grammarAccess.getConditionAccess().getOperatorAssignment_0()); 
            // InternalGameOfLifeDSL.g:1645:2: ( rule__Condition__OperatorAssignment_0 )
            // InternalGameOfLifeDSL.g:1645:3: rule__Condition__OperatorAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Condition__OperatorAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getOperatorAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__0__Impl"


    // $ANTLR start "rule__Condition__Group__1"
    // InternalGameOfLifeDSL.g:1653:1: rule__Condition__Group__1 : rule__Condition__Group__1__Impl ;
    public final void rule__Condition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1657:1: ( rule__Condition__Group__1__Impl )
            // InternalGameOfLifeDSL.g:1658:2: rule__Condition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__1"


    // $ANTLR start "rule__Condition__Group__1__Impl"
    // InternalGameOfLifeDSL.g:1664:1: rule__Condition__Group__1__Impl : ( ( rule__Condition__NeighborsAssignment_1 ) ) ;
    public final void rule__Condition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1668:1: ( ( ( rule__Condition__NeighborsAssignment_1 ) ) )
            // InternalGameOfLifeDSL.g:1669:1: ( ( rule__Condition__NeighborsAssignment_1 ) )
            {
            // InternalGameOfLifeDSL.g:1669:1: ( ( rule__Condition__NeighborsAssignment_1 ) )
            // InternalGameOfLifeDSL.g:1670:2: ( rule__Condition__NeighborsAssignment_1 )
            {
             before(grammarAccess.getConditionAccess().getNeighborsAssignment_1()); 
            // InternalGameOfLifeDSL.g:1671:2: ( rule__Condition__NeighborsAssignment_1 )
            // InternalGameOfLifeDSL.g:1671:3: rule__Condition__NeighborsAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Condition__NeighborsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getNeighborsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__1__Impl"


    // $ANTLR start "rule__GameSpec__ActiveAssignment_0"
    // InternalGameOfLifeDSL.g:1680:1: rule__GameSpec__ActiveAssignment_0 : ( ( 'active' ) ) ;
    public final void rule__GameSpec__ActiveAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1684:1: ( ( ( 'active' ) ) )
            // InternalGameOfLifeDSL.g:1685:2: ( ( 'active' ) )
            {
            // InternalGameOfLifeDSL.g:1685:2: ( ( 'active' ) )
            // InternalGameOfLifeDSL.g:1686:3: ( 'active' )
            {
             before(grammarAccess.getGameSpecAccess().getActiveActiveKeyword_0_0()); 
            // InternalGameOfLifeDSL.g:1687:3: ( 'active' )
            // InternalGameOfLifeDSL.g:1688:4: 'active'
            {
             before(grammarAccess.getGameSpecAccess().getActiveActiveKeyword_0_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getGameSpecAccess().getActiveActiveKeyword_0_0()); 

            }

             after(grammarAccess.getGameSpecAccess().getActiveActiveKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__ActiveAssignment_0"


    // $ANTLR start "rule__GameSpec__GridAssignment_1"
    // InternalGameOfLifeDSL.g:1699:1: rule__GameSpec__GridAssignment_1 : ( ruleGridSize ) ;
    public final void rule__GameSpec__GridAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1703:1: ( ( ruleGridSize ) )
            // InternalGameOfLifeDSL.g:1704:2: ( ruleGridSize )
            {
            // InternalGameOfLifeDSL.g:1704:2: ( ruleGridSize )
            // InternalGameOfLifeDSL.g:1705:3: ruleGridSize
            {
             before(grammarAccess.getGameSpecAccess().getGridGridSizeParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleGridSize();

            state._fsp--;

             after(grammarAccess.getGameSpecAccess().getGridGridSizeParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__GridAssignment_1"


    // $ANTLR start "rule__GameSpec__InitialAssignment_2"
    // InternalGameOfLifeDSL.g:1714:1: rule__GameSpec__InitialAssignment_2 : ( ruleInitial ) ;
    public final void rule__GameSpec__InitialAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1718:1: ( ( ruleInitial ) )
            // InternalGameOfLifeDSL.g:1719:2: ( ruleInitial )
            {
            // InternalGameOfLifeDSL.g:1719:2: ( ruleInitial )
            // InternalGameOfLifeDSL.g:1720:3: ruleInitial
            {
             before(grammarAccess.getGameSpecAccess().getInitialInitialParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleInitial();

            state._fsp--;

             after(grammarAccess.getGameSpecAccess().getInitialInitialParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__InitialAssignment_2"


    // $ANTLR start "rule__GameSpec__RulesAssignment_3"
    // InternalGameOfLifeDSL.g:1729:1: rule__GameSpec__RulesAssignment_3 : ( ruleRules ) ;
    public final void rule__GameSpec__RulesAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1733:1: ( ( ruleRules ) )
            // InternalGameOfLifeDSL.g:1734:2: ( ruleRules )
            {
            // InternalGameOfLifeDSL.g:1734:2: ( ruleRules )
            // InternalGameOfLifeDSL.g:1735:3: ruleRules
            {
             before(grammarAccess.getGameSpecAccess().getRulesRulesParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleRules();

            state._fsp--;

             after(grammarAccess.getGameSpecAccess().getRulesRulesParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameSpec__RulesAssignment_3"


    // $ANTLR start "rule__Coordinates__CoordlistAssignment_3"
    // InternalGameOfLifeDSL.g:1744:1: rule__Coordinates__CoordlistAssignment_3 : ( ruleCoordinate ) ;
    public final void rule__Coordinates__CoordlistAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1748:1: ( ( ruleCoordinate ) )
            // InternalGameOfLifeDSL.g:1749:2: ( ruleCoordinate )
            {
            // InternalGameOfLifeDSL.g:1749:2: ( ruleCoordinate )
            // InternalGameOfLifeDSL.g:1750:3: ruleCoordinate
            {
             before(grammarAccess.getCoordinatesAccess().getCoordlistCoordinateParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getCoordinatesAccess().getCoordlistCoordinateParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinates__CoordlistAssignment_3"


    // $ANTLR start "rule__Coordinate__XAssignment_1"
    // InternalGameOfLifeDSL.g:1759:1: rule__Coordinate__XAssignment_1 : ( RULE_INT ) ;
    public final void rule__Coordinate__XAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1763:1: ( ( RULE_INT ) )
            // InternalGameOfLifeDSL.g:1764:2: ( RULE_INT )
            {
            // InternalGameOfLifeDSL.g:1764:2: ( RULE_INT )
            // InternalGameOfLifeDSL.g:1765:3: RULE_INT
            {
             before(grammarAccess.getCoordinateAccess().getXINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getCoordinateAccess().getXINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__XAssignment_1"


    // $ANTLR start "rule__Coordinate__YAssignment_3"
    // InternalGameOfLifeDSL.g:1774:1: rule__Coordinate__YAssignment_3 : ( RULE_INT ) ;
    public final void rule__Coordinate__YAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1778:1: ( ( RULE_INT ) )
            // InternalGameOfLifeDSL.g:1779:2: ( RULE_INT )
            {
            // InternalGameOfLifeDSL.g:1779:2: ( RULE_INT )
            // InternalGameOfLifeDSL.g:1780:3: RULE_INT
            {
             before(grammarAccess.getCoordinateAccess().getYINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getCoordinateAccess().getYINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__YAssignment_3"


    // $ANTLR start "rule__GridSize__GridNumAssignment_3"
    // InternalGameOfLifeDSL.g:1789:1: rule__GridSize__GridNumAssignment_3 : ( ruleGrid ) ;
    public final void rule__GridSize__GridNumAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1793:1: ( ( ruleGrid ) )
            // InternalGameOfLifeDSL.g:1794:2: ( ruleGrid )
            {
            // InternalGameOfLifeDSL.g:1794:2: ( ruleGrid )
            // InternalGameOfLifeDSL.g:1795:3: ruleGrid
            {
             before(grammarAccess.getGridSizeAccess().getGridNumGridParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleGrid();

            state._fsp--;

             after(grammarAccess.getGridSizeAccess().getGridNumGridParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GridSize__GridNumAssignment_3"


    // $ANTLR start "rule__Initial__CoordinatesAssignment_2"
    // InternalGameOfLifeDSL.g:1804:1: rule__Initial__CoordinatesAssignment_2 : ( ruleCoordinates ) ;
    public final void rule__Initial__CoordinatesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1808:1: ( ( ruleCoordinates ) )
            // InternalGameOfLifeDSL.g:1809:2: ( ruleCoordinates )
            {
            // InternalGameOfLifeDSL.g:1809:2: ( ruleCoordinates )
            // InternalGameOfLifeDSL.g:1810:3: ruleCoordinates
            {
             before(grammarAccess.getInitialAccess().getCoordinatesCoordinatesParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinates();

            state._fsp--;

             after(grammarAccess.getInitialAccess().getCoordinatesCoordinatesParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__CoordinatesAssignment_2"


    // $ANTLR start "rule__Initial__PatternsAssignment_3_1"
    // InternalGameOfLifeDSL.g:1819:1: rule__Initial__PatternsAssignment_3_1 : ( rulePatternRLE ) ;
    public final void rule__Initial__PatternsAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1823:1: ( ( rulePatternRLE ) )
            // InternalGameOfLifeDSL.g:1824:2: ( rulePatternRLE )
            {
            // InternalGameOfLifeDSL.g:1824:2: ( rulePatternRLE )
            // InternalGameOfLifeDSL.g:1825:3: rulePatternRLE
            {
             before(grammarAccess.getInitialAccess().getPatternsPatternRLEParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            rulePatternRLE();

            state._fsp--;

             after(grammarAccess.getInitialAccess().getPatternsPatternRLEParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Initial__PatternsAssignment_3_1"


    // $ANTLR start "rule__PatternRLE__StartAssignment_0"
    // InternalGameOfLifeDSL.g:1834:1: rule__PatternRLE__StartAssignment_0 : ( ruleCoordinate ) ;
    public final void rule__PatternRLE__StartAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1838:1: ( ( ruleCoordinate ) )
            // InternalGameOfLifeDSL.g:1839:2: ( ruleCoordinate )
            {
            // InternalGameOfLifeDSL.g:1839:2: ( ruleCoordinate )
            // InternalGameOfLifeDSL.g:1840:3: ruleCoordinate
            {
             before(grammarAccess.getPatternRLEAccess().getStartCoordinateParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getPatternRLEAccess().getStartCoordinateParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__StartAssignment_0"


    // $ANTLR start "rule__PatternRLE__PatternAssignment_1"
    // InternalGameOfLifeDSL.g:1849:1: rule__PatternRLE__PatternAssignment_1 : ( RULE_STRING ) ;
    public final void rule__PatternRLE__PatternAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1853:1: ( ( RULE_STRING ) )
            // InternalGameOfLifeDSL.g:1854:2: ( RULE_STRING )
            {
            // InternalGameOfLifeDSL.g:1854:2: ( RULE_STRING )
            // InternalGameOfLifeDSL.g:1855:3: RULE_STRING
            {
             before(grammarAccess.getPatternRLEAccess().getPatternSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPatternRLEAccess().getPatternSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PatternRLE__PatternAssignment_1"


    // $ANTLR start "rule__Grid__XAssignment_1"
    // InternalGameOfLifeDSL.g:1864:1: rule__Grid__XAssignment_1 : ( RULE_INT ) ;
    public final void rule__Grid__XAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1868:1: ( ( RULE_INT ) )
            // InternalGameOfLifeDSL.g:1869:2: ( RULE_INT )
            {
            // InternalGameOfLifeDSL.g:1869:2: ( RULE_INT )
            // InternalGameOfLifeDSL.g:1870:3: RULE_INT
            {
             before(grammarAccess.getGridAccess().getXINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getGridAccess().getXINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__XAssignment_1"


    // $ANTLR start "rule__Grid__YAssignment_3"
    // InternalGameOfLifeDSL.g:1879:1: rule__Grid__YAssignment_3 : ( RULE_INT ) ;
    public final void rule__Grid__YAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1883:1: ( ( RULE_INT ) )
            // InternalGameOfLifeDSL.g:1884:2: ( RULE_INT )
            {
            // InternalGameOfLifeDSL.g:1884:2: ( RULE_INT )
            // InternalGameOfLifeDSL.g:1885:3: RULE_INT
            {
             before(grammarAccess.getGridAccess().getYINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getGridAccess().getYINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Grid__YAssignment_3"


    // $ANTLR start "rule__Rules__DefaultConsequenceAssignment_2_1"
    // InternalGameOfLifeDSL.g:1894:1: rule__Rules__DefaultConsequenceAssignment_2_1 : ( ruleDefaultConsequence ) ;
    public final void rule__Rules__DefaultConsequenceAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1898:1: ( ( ruleDefaultConsequence ) )
            // InternalGameOfLifeDSL.g:1899:2: ( ruleDefaultConsequence )
            {
            // InternalGameOfLifeDSL.g:1899:2: ( ruleDefaultConsequence )
            // InternalGameOfLifeDSL.g:1900:3: ruleDefaultConsequence
            {
             before(grammarAccess.getRulesAccess().getDefaultConsequenceDefaultConsequenceEnumRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDefaultConsequence();

            state._fsp--;

             after(grammarAccess.getRulesAccess().getDefaultConsequenceDefaultConsequenceEnumRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__DefaultConsequenceAssignment_2_1"


    // $ANTLR start "rule__Rules__RulesAssignment_3"
    // InternalGameOfLifeDSL.g:1909:1: rule__Rules__RulesAssignment_3 : ( ruleRule ) ;
    public final void rule__Rules__RulesAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1913:1: ( ( ruleRule ) )
            // InternalGameOfLifeDSL.g:1914:2: ( ruleRule )
            {
            // InternalGameOfLifeDSL.g:1914:2: ( ruleRule )
            // InternalGameOfLifeDSL.g:1915:3: ruleRule
            {
             before(grammarAccess.getRulesAccess().getRulesRuleParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getRulesAccess().getRulesRuleParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rules__RulesAssignment_3"


    // $ANTLR start "rule__Rule__ConsequenceAssignment_0"
    // InternalGameOfLifeDSL.g:1924:1: rule__Rule__ConsequenceAssignment_0 : ( ruleConsequence ) ;
    public final void rule__Rule__ConsequenceAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1928:1: ( ( ruleConsequence ) )
            // InternalGameOfLifeDSL.g:1929:2: ( ruleConsequence )
            {
            // InternalGameOfLifeDSL.g:1929:2: ( ruleConsequence )
            // InternalGameOfLifeDSL.g:1930:3: ruleConsequence
            {
             before(grammarAccess.getRuleAccess().getConsequenceConsequenceEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleConsequence();

            state._fsp--;

             after(grammarAccess.getRuleAccess().getConsequenceConsequenceEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__ConsequenceAssignment_0"


    // $ANTLR start "rule__Rule__ReasonAssignment_1"
    // InternalGameOfLifeDSL.g:1939:1: rule__Rule__ReasonAssignment_1 : ( ruleReason ) ;
    public final void rule__Rule__ReasonAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1943:1: ( ( ruleReason ) )
            // InternalGameOfLifeDSL.g:1944:2: ( ruleReason )
            {
            // InternalGameOfLifeDSL.g:1944:2: ( ruleReason )
            // InternalGameOfLifeDSL.g:1945:3: ruleReason
            {
             before(grammarAccess.getRuleAccess().getReasonReasonParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleReason();

            state._fsp--;

             after(grammarAccess.getRuleAccess().getReasonReasonParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__ReasonAssignment_1"


    // $ANTLR start "rule__Reason__ConditionAssignment_2"
    // InternalGameOfLifeDSL.g:1954:1: rule__Reason__ConditionAssignment_2 : ( ruleCondition ) ;
    public final void rule__Reason__ConditionAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1958:1: ( ( ruleCondition ) )
            // InternalGameOfLifeDSL.g:1959:2: ( ruleCondition )
            {
            // InternalGameOfLifeDSL.g:1959:2: ( ruleCondition )
            // InternalGameOfLifeDSL.g:1960:3: ruleCondition
            {
             before(grammarAccess.getReasonAccess().getConditionConditionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getReasonAccess().getConditionConditionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reason__ConditionAssignment_2"


    // $ANTLR start "rule__Condition__OperatorAssignment_0"
    // InternalGameOfLifeDSL.g:1969:1: rule__Condition__OperatorAssignment_0 : ( ruleOperator ) ;
    public final void rule__Condition__OperatorAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1973:1: ( ( ruleOperator ) )
            // InternalGameOfLifeDSL.g:1974:2: ( ruleOperator )
            {
            // InternalGameOfLifeDSL.g:1974:2: ( ruleOperator )
            // InternalGameOfLifeDSL.g:1975:3: ruleOperator
            {
             before(grammarAccess.getConditionAccess().getOperatorOperatorParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleOperator();

            state._fsp--;

             after(grammarAccess.getConditionAccess().getOperatorOperatorParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__OperatorAssignment_0"


    // $ANTLR start "rule__Condition__NeighborsAssignment_1"
    // InternalGameOfLifeDSL.g:1984:1: rule__Condition__NeighborsAssignment_1 : ( RULE_INT ) ;
    public final void rule__Condition__NeighborsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:1988:1: ( ( RULE_INT ) )
            // InternalGameOfLifeDSL.g:1989:2: ( RULE_INT )
            {
            // InternalGameOfLifeDSL.g:1989:2: ( RULE_INT )
            // InternalGameOfLifeDSL.g:1990:3: RULE_INT
            {
             before(grammarAccess.getConditionAccess().getNeighborsINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getConditionAccess().getNeighborsINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__NeighborsAssignment_1"


    // $ANTLR start "rule__Operator__SMALLERAssignment_0"
    // InternalGameOfLifeDSL.g:1999:1: rule__Operator__SMALLERAssignment_0 : ( ( '<' ) ) ;
    public final void rule__Operator__SMALLERAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:2003:1: ( ( ( '<' ) ) )
            // InternalGameOfLifeDSL.g:2004:2: ( ( '<' ) )
            {
            // InternalGameOfLifeDSL.g:2004:2: ( ( '<' ) )
            // InternalGameOfLifeDSL.g:2005:3: ( '<' )
            {
             before(grammarAccess.getOperatorAccess().getSMALLERLessThanSignKeyword_0_0()); 
            // InternalGameOfLifeDSL.g:2006:3: ( '<' )
            // InternalGameOfLifeDSL.g:2007:4: '<'
            {
             before(grammarAccess.getOperatorAccess().getSMALLERLessThanSignKeyword_0_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getOperatorAccess().getSMALLERLessThanSignKeyword_0_0()); 

            }

             after(grammarAccess.getOperatorAccess().getSMALLERLessThanSignKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Operator__SMALLERAssignment_0"


    // $ANTLR start "rule__Operator__LARGERAssignment_1"
    // InternalGameOfLifeDSL.g:2018:1: rule__Operator__LARGERAssignment_1 : ( ( '>' ) ) ;
    public final void rule__Operator__LARGERAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:2022:1: ( ( ( '>' ) ) )
            // InternalGameOfLifeDSL.g:2023:2: ( ( '>' ) )
            {
            // InternalGameOfLifeDSL.g:2023:2: ( ( '>' ) )
            // InternalGameOfLifeDSL.g:2024:3: ( '>' )
            {
             before(grammarAccess.getOperatorAccess().getLARGERGreaterThanSignKeyword_1_0()); 
            // InternalGameOfLifeDSL.g:2025:3: ( '>' )
            // InternalGameOfLifeDSL.g:2026:4: '>'
            {
             before(grammarAccess.getOperatorAccess().getLARGERGreaterThanSignKeyword_1_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getOperatorAccess().getLARGERGreaterThanSignKeyword_1_0()); 

            }

             after(grammarAccess.getOperatorAccess().getLARGERGreaterThanSignKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Operator__LARGERAssignment_1"


    // $ANTLR start "rule__Operator__EQUALAssignment_2"
    // InternalGameOfLifeDSL.g:2037:1: rule__Operator__EQUALAssignment_2 : ( ( '=' ) ) ;
    public final void rule__Operator__EQUALAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameOfLifeDSL.g:2041:1: ( ( ( '=' ) ) )
            // InternalGameOfLifeDSL.g:2042:2: ( ( '=' ) )
            {
            // InternalGameOfLifeDSL.g:2042:2: ( ( '=' ) )
            // InternalGameOfLifeDSL.g:2043:3: ( '=' )
            {
             before(grammarAccess.getOperatorAccess().getEQUALEqualsSignKeyword_2_0()); 
            // InternalGameOfLifeDSL.g:2044:3: ( '=' )
            // InternalGameOfLifeDSL.g:2045:4: '='
            {
             before(grammarAccess.getOperatorAccess().getEQUALEqualsSignKeyword_2_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getOperatorAccess().getEQUALEqualsSignKeyword_2_0()); 

            }

             after(grammarAccess.getOperatorAccess().getEQUALEqualsSignKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Operator__EQUALAssignment_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000001300000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000408000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002007000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000007002L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000003800L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000060010000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});

}