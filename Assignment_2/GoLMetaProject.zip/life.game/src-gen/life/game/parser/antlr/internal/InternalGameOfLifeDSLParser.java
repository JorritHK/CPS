package life.game.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import life.game.services.GameOfLifeDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGameOfLifeDSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_STRING", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'active'", "'Coordinates'", "'='", "'['", "','", "']'", "'GridSize'", "'Initial:'", "'Patterns:'", "'x'", "'Rules:'", "'default:'", "'if'", "'companions'", "'<'", "'>'", "'empty'", "'survive'", "'die'", "'be born'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int RULE_ID=6;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalGameOfLifeDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGameOfLifeDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGameOfLifeDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGameOfLifeDSL.g"; }



     	private GameOfLifeDSLGrammarAccess grammarAccess;

        public InternalGameOfLifeDSLParser(TokenStream input, GameOfLifeDSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "GameSpec";
       	}

       	@Override
       	protected GameOfLifeDSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleGameSpec"
    // InternalGameOfLifeDSL.g:65:1: entryRuleGameSpec returns [EObject current=null] : iv_ruleGameSpec= ruleGameSpec EOF ;
    public final EObject entryRuleGameSpec() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGameSpec = null;


        try {
            // InternalGameOfLifeDSL.g:65:49: (iv_ruleGameSpec= ruleGameSpec EOF )
            // InternalGameOfLifeDSL.g:66:2: iv_ruleGameSpec= ruleGameSpec EOF
            {
             newCompositeNode(grammarAccess.getGameSpecRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGameSpec=ruleGameSpec();

            state._fsp--;

             current =iv_ruleGameSpec; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGameSpec"


    // $ANTLR start "ruleGameSpec"
    // InternalGameOfLifeDSL.g:72:1: ruleGameSpec returns [EObject current=null] : ( ( (lv_active_0_0= 'active' ) )? ( (lv_grid_1_0= ruleGridSize ) )? ( (lv_initial_2_0= ruleInitial ) )? ( (lv_rules_3_0= ruleRules ) ) ) ;
    public final EObject ruleGameSpec() throws RecognitionException {
        EObject current = null;

        Token lv_active_0_0=null;
        EObject lv_grid_1_0 = null;

        EObject lv_initial_2_0 = null;

        EObject lv_rules_3_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:78:2: ( ( ( (lv_active_0_0= 'active' ) )? ( (lv_grid_1_0= ruleGridSize ) )? ( (lv_initial_2_0= ruleInitial ) )? ( (lv_rules_3_0= ruleRules ) ) ) )
            // InternalGameOfLifeDSL.g:79:2: ( ( (lv_active_0_0= 'active' ) )? ( (lv_grid_1_0= ruleGridSize ) )? ( (lv_initial_2_0= ruleInitial ) )? ( (lv_rules_3_0= ruleRules ) ) )
            {
            // InternalGameOfLifeDSL.g:79:2: ( ( (lv_active_0_0= 'active' ) )? ( (lv_grid_1_0= ruleGridSize ) )? ( (lv_initial_2_0= ruleInitial ) )? ( (lv_rules_3_0= ruleRules ) ) )
            // InternalGameOfLifeDSL.g:80:3: ( (lv_active_0_0= 'active' ) )? ( (lv_grid_1_0= ruleGridSize ) )? ( (lv_initial_2_0= ruleInitial ) )? ( (lv_rules_3_0= ruleRules ) )
            {
            // InternalGameOfLifeDSL.g:80:3: ( (lv_active_0_0= 'active' ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalGameOfLifeDSL.g:81:4: (lv_active_0_0= 'active' )
                    {
                    // InternalGameOfLifeDSL.g:81:4: (lv_active_0_0= 'active' )
                    // InternalGameOfLifeDSL.g:82:5: lv_active_0_0= 'active'
                    {
                    lv_active_0_0=(Token)match(input,11,FOLLOW_3); 

                    					newLeafNode(lv_active_0_0, grammarAccess.getGameSpecAccess().getActiveActiveKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getGameSpecRule());
                    					}
                    					setWithLastConsumed(current, "active", lv_active_0_0, "active");
                    				

                    }


                    }
                    break;

            }

            // InternalGameOfLifeDSL.g:94:3: ( (lv_grid_1_0= ruleGridSize ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==17) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalGameOfLifeDSL.g:95:4: (lv_grid_1_0= ruleGridSize )
                    {
                    // InternalGameOfLifeDSL.g:95:4: (lv_grid_1_0= ruleGridSize )
                    // InternalGameOfLifeDSL.g:96:5: lv_grid_1_0= ruleGridSize
                    {

                    					newCompositeNode(grammarAccess.getGameSpecAccess().getGridGridSizeParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_3);
                    lv_grid_1_0=ruleGridSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getGameSpecRule());
                    					}
                    					set(
                    						current,
                    						"grid",
                    						lv_grid_1_0,
                    						"life.game.GameOfLifeDSL.GridSize");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGameOfLifeDSL.g:113:3: ( (lv_initial_2_0= ruleInitial ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==18) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalGameOfLifeDSL.g:114:4: (lv_initial_2_0= ruleInitial )
                    {
                    // InternalGameOfLifeDSL.g:114:4: (lv_initial_2_0= ruleInitial )
                    // InternalGameOfLifeDSL.g:115:5: lv_initial_2_0= ruleInitial
                    {

                    					newCompositeNode(grammarAccess.getGameSpecAccess().getInitialInitialParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_3);
                    lv_initial_2_0=ruleInitial();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getGameSpecRule());
                    					}
                    					set(
                    						current,
                    						"initial",
                    						lv_initial_2_0,
                    						"life.game.GameOfLifeDSL.Initial");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGameOfLifeDSL.g:132:3: ( (lv_rules_3_0= ruleRules ) )
            // InternalGameOfLifeDSL.g:133:4: (lv_rules_3_0= ruleRules )
            {
            // InternalGameOfLifeDSL.g:133:4: (lv_rules_3_0= ruleRules )
            // InternalGameOfLifeDSL.g:134:5: lv_rules_3_0= ruleRules
            {

            					newCompositeNode(grammarAccess.getGameSpecAccess().getRulesRulesParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_rules_3_0=ruleRules();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameSpecRule());
            					}
            					set(
            						current,
            						"rules",
            						lv_rules_3_0,
            						"life.game.GameOfLifeDSL.Rules");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGameSpec"


    // $ANTLR start "entryRuleCoordinates"
    // InternalGameOfLifeDSL.g:155:1: entryRuleCoordinates returns [EObject current=null] : iv_ruleCoordinates= ruleCoordinates EOF ;
    public final EObject entryRuleCoordinates() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCoordinates = null;


        try {
            // InternalGameOfLifeDSL.g:155:52: (iv_ruleCoordinates= ruleCoordinates EOF )
            // InternalGameOfLifeDSL.g:156:2: iv_ruleCoordinates= ruleCoordinates EOF
            {
             newCompositeNode(grammarAccess.getCoordinatesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCoordinates=ruleCoordinates();

            state._fsp--;

             current =iv_ruleCoordinates; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCoordinates"


    // $ANTLR start "ruleCoordinates"
    // InternalGameOfLifeDSL.g:162:1: ruleCoordinates returns [EObject current=null] : ( () otherlv_1= 'Coordinates' otherlv_2= '=' ( (lv_coordlist_3_0= ruleCoordinate ) )* ) ;
    public final EObject ruleCoordinates() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        EObject lv_coordlist_3_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:168:2: ( ( () otherlv_1= 'Coordinates' otherlv_2= '=' ( (lv_coordlist_3_0= ruleCoordinate ) )* ) )
            // InternalGameOfLifeDSL.g:169:2: ( () otherlv_1= 'Coordinates' otherlv_2= '=' ( (lv_coordlist_3_0= ruleCoordinate ) )* )
            {
            // InternalGameOfLifeDSL.g:169:2: ( () otherlv_1= 'Coordinates' otherlv_2= '=' ( (lv_coordlist_3_0= ruleCoordinate ) )* )
            // InternalGameOfLifeDSL.g:170:3: () otherlv_1= 'Coordinates' otherlv_2= '=' ( (lv_coordlist_3_0= ruleCoordinate ) )*
            {
            // InternalGameOfLifeDSL.g:170:3: ()
            // InternalGameOfLifeDSL.g:171:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCoordinatesAccess().getCoordinatesAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getCoordinatesAccess().getCoordinatesKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getCoordinatesAccess().getEqualsSignKeyword_2());
            		
            // InternalGameOfLifeDSL.g:185:3: ( (lv_coordlist_3_0= ruleCoordinate ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==14) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalGameOfLifeDSL.g:186:4: (lv_coordlist_3_0= ruleCoordinate )
            	    {
            	    // InternalGameOfLifeDSL.g:186:4: (lv_coordlist_3_0= ruleCoordinate )
            	    // InternalGameOfLifeDSL.g:187:5: lv_coordlist_3_0= ruleCoordinate
            	    {

            	    					newCompositeNode(grammarAccess.getCoordinatesAccess().getCoordlistCoordinateParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_coordlist_3_0=ruleCoordinate();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCoordinatesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"coordlist",
            	    						lv_coordlist_3_0,
            	    						"life.game.GameOfLifeDSL.Coordinate");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoordinates"


    // $ANTLR start "entryRuleCoordinate"
    // InternalGameOfLifeDSL.g:208:1: entryRuleCoordinate returns [EObject current=null] : iv_ruleCoordinate= ruleCoordinate EOF ;
    public final EObject entryRuleCoordinate() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCoordinate = null;


        try {
            // InternalGameOfLifeDSL.g:208:51: (iv_ruleCoordinate= ruleCoordinate EOF )
            // InternalGameOfLifeDSL.g:209:2: iv_ruleCoordinate= ruleCoordinate EOF
            {
             newCompositeNode(grammarAccess.getCoordinateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCoordinate=ruleCoordinate();

            state._fsp--;

             current =iv_ruleCoordinate; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCoordinate"


    // $ANTLR start "ruleCoordinate"
    // InternalGameOfLifeDSL.g:215:1: ruleCoordinate returns [EObject current=null] : (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' ) ;
    public final EObject ruleCoordinate() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_x_1_0=null;
        Token otherlv_2=null;
        Token lv_y_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:221:2: ( (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' ) )
            // InternalGameOfLifeDSL.g:222:2: (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' )
            {
            // InternalGameOfLifeDSL.g:222:2: (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' )
            // InternalGameOfLifeDSL.g:223:3: otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']'
            {
            otherlv_0=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getCoordinateAccess().getLeftSquareBracketKeyword_0());
            		
            // InternalGameOfLifeDSL.g:227:3: ( (lv_x_1_0= RULE_INT ) )
            // InternalGameOfLifeDSL.g:228:4: (lv_x_1_0= RULE_INT )
            {
            // InternalGameOfLifeDSL.g:228:4: (lv_x_1_0= RULE_INT )
            // InternalGameOfLifeDSL.g:229:5: lv_x_1_0= RULE_INT
            {
            lv_x_1_0=(Token)match(input,RULE_INT,FOLLOW_7); 

            					newLeafNode(lv_x_1_0, grammarAccess.getCoordinateAccess().getXINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCoordinateRule());
            					}
            					setWithLastConsumed(
            						current,
            						"x",
            						lv_x_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCoordinateAccess().getCommaKeyword_2());
            		
            // InternalGameOfLifeDSL.g:249:3: ( (lv_y_3_0= RULE_INT ) )
            // InternalGameOfLifeDSL.g:250:4: (lv_y_3_0= RULE_INT )
            {
            // InternalGameOfLifeDSL.g:250:4: (lv_y_3_0= RULE_INT )
            // InternalGameOfLifeDSL.g:251:5: lv_y_3_0= RULE_INT
            {
            lv_y_3_0=(Token)match(input,RULE_INT,FOLLOW_8); 

            					newLeafNode(lv_y_3_0, grammarAccess.getCoordinateAccess().getYINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCoordinateRule());
            					}
            					setWithLastConsumed(
            						current,
            						"y",
            						lv_y_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCoordinateAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoordinate"


    // $ANTLR start "entryRuleGridSize"
    // InternalGameOfLifeDSL.g:275:1: entryRuleGridSize returns [EObject current=null] : iv_ruleGridSize= ruleGridSize EOF ;
    public final EObject entryRuleGridSize() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGridSize = null;


        try {
            // InternalGameOfLifeDSL.g:275:49: (iv_ruleGridSize= ruleGridSize EOF )
            // InternalGameOfLifeDSL.g:276:2: iv_ruleGridSize= ruleGridSize EOF
            {
             newCompositeNode(grammarAccess.getGridSizeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGridSize=ruleGridSize();

            state._fsp--;

             current =iv_ruleGridSize; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGridSize"


    // $ANTLR start "ruleGridSize"
    // InternalGameOfLifeDSL.g:282:1: ruleGridSize returns [EObject current=null] : ( () otherlv_1= 'GridSize' otherlv_2= '=' ( (lv_gridNum_3_0= ruleGrid ) ) ) ;
    public final EObject ruleGridSize() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        EObject lv_gridNum_3_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:288:2: ( ( () otherlv_1= 'GridSize' otherlv_2= '=' ( (lv_gridNum_3_0= ruleGrid ) ) ) )
            // InternalGameOfLifeDSL.g:289:2: ( () otherlv_1= 'GridSize' otherlv_2= '=' ( (lv_gridNum_3_0= ruleGrid ) ) )
            {
            // InternalGameOfLifeDSL.g:289:2: ( () otherlv_1= 'GridSize' otherlv_2= '=' ( (lv_gridNum_3_0= ruleGrid ) ) )
            // InternalGameOfLifeDSL.g:290:3: () otherlv_1= 'GridSize' otherlv_2= '=' ( (lv_gridNum_3_0= ruleGrid ) )
            {
            // InternalGameOfLifeDSL.g:290:3: ()
            // InternalGameOfLifeDSL.g:291:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getGridSizeAccess().getGridSizeAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,17,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getGridSizeAccess().getGridSizeKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_9); 

            			newLeafNode(otherlv_2, grammarAccess.getGridSizeAccess().getEqualsSignKeyword_2());
            		
            // InternalGameOfLifeDSL.g:305:3: ( (lv_gridNum_3_0= ruleGrid ) )
            // InternalGameOfLifeDSL.g:306:4: (lv_gridNum_3_0= ruleGrid )
            {
            // InternalGameOfLifeDSL.g:306:4: (lv_gridNum_3_0= ruleGrid )
            // InternalGameOfLifeDSL.g:307:5: lv_gridNum_3_0= ruleGrid
            {

            					newCompositeNode(grammarAccess.getGridSizeAccess().getGridNumGridParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_gridNum_3_0=ruleGrid();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGridSizeRule());
            					}
            					set(
            						current,
            						"gridNum",
            						lv_gridNum_3_0,
            						"life.game.GameOfLifeDSL.Grid");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGridSize"


    // $ANTLR start "entryRuleInitial"
    // InternalGameOfLifeDSL.g:328:1: entryRuleInitial returns [EObject current=null] : iv_ruleInitial= ruleInitial EOF ;
    public final EObject entryRuleInitial() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInitial = null;


        try {
            // InternalGameOfLifeDSL.g:328:48: (iv_ruleInitial= ruleInitial EOF )
            // InternalGameOfLifeDSL.g:329:2: iv_ruleInitial= ruleInitial EOF
            {
             newCompositeNode(grammarAccess.getInitialRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInitial=ruleInitial();

            state._fsp--;

             current =iv_ruleInitial; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInitial"


    // $ANTLR start "ruleInitial"
    // InternalGameOfLifeDSL.g:335:1: ruleInitial returns [EObject current=null] : ( () otherlv_1= 'Initial:' ( (lv_coordinates_2_0= ruleCoordinates ) )? (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )? ) ;
    public final EObject ruleInitial() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_coordinates_2_0 = null;

        EObject lv_patterns_4_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:341:2: ( ( () otherlv_1= 'Initial:' ( (lv_coordinates_2_0= ruleCoordinates ) )? (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )? ) )
            // InternalGameOfLifeDSL.g:342:2: ( () otherlv_1= 'Initial:' ( (lv_coordinates_2_0= ruleCoordinates ) )? (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )? )
            {
            // InternalGameOfLifeDSL.g:342:2: ( () otherlv_1= 'Initial:' ( (lv_coordinates_2_0= ruleCoordinates ) )? (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )? )
            // InternalGameOfLifeDSL.g:343:3: () otherlv_1= 'Initial:' ( (lv_coordinates_2_0= ruleCoordinates ) )? (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )?
            {
            // InternalGameOfLifeDSL.g:343:3: ()
            // InternalGameOfLifeDSL.g:344:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInitialAccess().getInitialAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,18,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getInitialAccess().getInitialKeyword_1());
            		
            // InternalGameOfLifeDSL.g:354:3: ( (lv_coordinates_2_0= ruleCoordinates ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==12) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalGameOfLifeDSL.g:355:4: (lv_coordinates_2_0= ruleCoordinates )
                    {
                    // InternalGameOfLifeDSL.g:355:4: (lv_coordinates_2_0= ruleCoordinates )
                    // InternalGameOfLifeDSL.g:356:5: lv_coordinates_2_0= ruleCoordinates
                    {

                    					newCompositeNode(grammarAccess.getInitialAccess().getCoordinatesCoordinatesParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_11);
                    lv_coordinates_2_0=ruleCoordinates();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getInitialRule());
                    					}
                    					set(
                    						current,
                    						"coordinates",
                    						lv_coordinates_2_0,
                    						"life.game.GameOfLifeDSL.Coordinates");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGameOfLifeDSL.g:373:3: (otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )* )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalGameOfLifeDSL.g:374:4: otherlv_3= 'Patterns:' ( (lv_patterns_4_0= rulePatternRLE ) )*
                    {
                    otherlv_3=(Token)match(input,19,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getInitialAccess().getPatternsKeyword_3_0());
                    			
                    // InternalGameOfLifeDSL.g:378:4: ( (lv_patterns_4_0= rulePatternRLE ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==14) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalGameOfLifeDSL.g:379:5: (lv_patterns_4_0= rulePatternRLE )
                    	    {
                    	    // InternalGameOfLifeDSL.g:379:5: (lv_patterns_4_0= rulePatternRLE )
                    	    // InternalGameOfLifeDSL.g:380:6: lv_patterns_4_0= rulePatternRLE
                    	    {

                    	    						newCompositeNode(grammarAccess.getInitialAccess().getPatternsPatternRLEParserRuleCall_3_1_0());
                    	    					
                    	    pushFollow(FOLLOW_5);
                    	    lv_patterns_4_0=rulePatternRLE();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getInitialRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"patterns",
                    	    							lv_patterns_4_0,
                    	    							"life.game.GameOfLifeDSL.PatternRLE");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInitial"


    // $ANTLR start "entryRulePatternRLE"
    // InternalGameOfLifeDSL.g:402:1: entryRulePatternRLE returns [EObject current=null] : iv_rulePatternRLE= rulePatternRLE EOF ;
    public final EObject entryRulePatternRLE() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePatternRLE = null;


        try {
            // InternalGameOfLifeDSL.g:402:51: (iv_rulePatternRLE= rulePatternRLE EOF )
            // InternalGameOfLifeDSL.g:403:2: iv_rulePatternRLE= rulePatternRLE EOF
            {
             newCompositeNode(grammarAccess.getPatternRLERule()); 
            pushFollow(FOLLOW_1);
            iv_rulePatternRLE=rulePatternRLE();

            state._fsp--;

             current =iv_rulePatternRLE; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePatternRLE"


    // $ANTLR start "rulePatternRLE"
    // InternalGameOfLifeDSL.g:409:1: rulePatternRLE returns [EObject current=null] : ( ( (lv_start_0_0= ruleCoordinate ) ) ( (lv_pattern_1_0= RULE_STRING ) ) ) ;
    public final EObject rulePatternRLE() throws RecognitionException {
        EObject current = null;

        Token lv_pattern_1_0=null;
        EObject lv_start_0_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:415:2: ( ( ( (lv_start_0_0= ruleCoordinate ) ) ( (lv_pattern_1_0= RULE_STRING ) ) ) )
            // InternalGameOfLifeDSL.g:416:2: ( ( (lv_start_0_0= ruleCoordinate ) ) ( (lv_pattern_1_0= RULE_STRING ) ) )
            {
            // InternalGameOfLifeDSL.g:416:2: ( ( (lv_start_0_0= ruleCoordinate ) ) ( (lv_pattern_1_0= RULE_STRING ) ) )
            // InternalGameOfLifeDSL.g:417:3: ( (lv_start_0_0= ruleCoordinate ) ) ( (lv_pattern_1_0= RULE_STRING ) )
            {
            // InternalGameOfLifeDSL.g:417:3: ( (lv_start_0_0= ruleCoordinate ) )
            // InternalGameOfLifeDSL.g:418:4: (lv_start_0_0= ruleCoordinate )
            {
            // InternalGameOfLifeDSL.g:418:4: (lv_start_0_0= ruleCoordinate )
            // InternalGameOfLifeDSL.g:419:5: lv_start_0_0= ruleCoordinate
            {

            					newCompositeNode(grammarAccess.getPatternRLEAccess().getStartCoordinateParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_12);
            lv_start_0_0=ruleCoordinate();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPatternRLERule());
            					}
            					set(
            						current,
            						"start",
            						lv_start_0_0,
            						"life.game.GameOfLifeDSL.Coordinate");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameOfLifeDSL.g:436:3: ( (lv_pattern_1_0= RULE_STRING ) )
            // InternalGameOfLifeDSL.g:437:4: (lv_pattern_1_0= RULE_STRING )
            {
            // InternalGameOfLifeDSL.g:437:4: (lv_pattern_1_0= RULE_STRING )
            // InternalGameOfLifeDSL.g:438:5: lv_pattern_1_0= RULE_STRING
            {
            lv_pattern_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_pattern_1_0, grammarAccess.getPatternRLEAccess().getPatternSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPatternRLERule());
            					}
            					setWithLastConsumed(
            						current,
            						"pattern",
            						lv_pattern_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePatternRLE"


    // $ANTLR start "entryRuleGrid"
    // InternalGameOfLifeDSL.g:458:1: entryRuleGrid returns [EObject current=null] : iv_ruleGrid= ruleGrid EOF ;
    public final EObject entryRuleGrid() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGrid = null;


        try {
            // InternalGameOfLifeDSL.g:458:45: (iv_ruleGrid= ruleGrid EOF )
            // InternalGameOfLifeDSL.g:459:2: iv_ruleGrid= ruleGrid EOF
            {
             newCompositeNode(grammarAccess.getGridRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGrid=ruleGrid();

            state._fsp--;

             current =iv_ruleGrid; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGrid"


    // $ANTLR start "ruleGrid"
    // InternalGameOfLifeDSL.g:465:1: ruleGrid returns [EObject current=null] : (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= 'x' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' ) ;
    public final EObject ruleGrid() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_x_1_0=null;
        Token otherlv_2=null;
        Token lv_y_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:471:2: ( (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= 'x' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' ) )
            // InternalGameOfLifeDSL.g:472:2: (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= 'x' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' )
            {
            // InternalGameOfLifeDSL.g:472:2: (otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= 'x' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']' )
            // InternalGameOfLifeDSL.g:473:3: otherlv_0= '[' ( (lv_x_1_0= RULE_INT ) ) otherlv_2= 'x' ( (lv_y_3_0= RULE_INT ) ) otherlv_4= ']'
            {
            otherlv_0=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getGridAccess().getLeftSquareBracketKeyword_0());
            		
            // InternalGameOfLifeDSL.g:477:3: ( (lv_x_1_0= RULE_INT ) )
            // InternalGameOfLifeDSL.g:478:4: (lv_x_1_0= RULE_INT )
            {
            // InternalGameOfLifeDSL.g:478:4: (lv_x_1_0= RULE_INT )
            // InternalGameOfLifeDSL.g:479:5: lv_x_1_0= RULE_INT
            {
            lv_x_1_0=(Token)match(input,RULE_INT,FOLLOW_13); 

            					newLeafNode(lv_x_1_0, grammarAccess.getGridAccess().getXINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGridRule());
            					}
            					setWithLastConsumed(
            						current,
            						"x",
            						lv_x_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getGridAccess().getXKeyword_2());
            		
            // InternalGameOfLifeDSL.g:499:3: ( (lv_y_3_0= RULE_INT ) )
            // InternalGameOfLifeDSL.g:500:4: (lv_y_3_0= RULE_INT )
            {
            // InternalGameOfLifeDSL.g:500:4: (lv_y_3_0= RULE_INT )
            // InternalGameOfLifeDSL.g:501:5: lv_y_3_0= RULE_INT
            {
            lv_y_3_0=(Token)match(input,RULE_INT,FOLLOW_8); 

            					newLeafNode(lv_y_3_0, grammarAccess.getGridAccess().getYINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGridRule());
            					}
            					setWithLastConsumed(
            						current,
            						"y",
            						lv_y_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getGridAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGrid"


    // $ANTLR start "entryRuleRules"
    // InternalGameOfLifeDSL.g:525:1: entryRuleRules returns [EObject current=null] : iv_ruleRules= ruleRules EOF ;
    public final EObject entryRuleRules() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRules = null;


        try {
            // InternalGameOfLifeDSL.g:525:46: (iv_ruleRules= ruleRules EOF )
            // InternalGameOfLifeDSL.g:526:2: iv_ruleRules= ruleRules EOF
            {
             newCompositeNode(grammarAccess.getRulesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRules=ruleRules();

            state._fsp--;

             current =iv_ruleRules; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRules"


    // $ANTLR start "ruleRules"
    // InternalGameOfLifeDSL.g:532:1: ruleRules returns [EObject current=null] : ( () otherlv_1= 'Rules:' (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )? ( (lv_rules_4_0= ruleRule ) )* ) ;
    public final EObject ruleRules() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Enumerator lv_defaultConsequence_3_0 = null;

        EObject lv_rules_4_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:538:2: ( ( () otherlv_1= 'Rules:' (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )? ( (lv_rules_4_0= ruleRule ) )* ) )
            // InternalGameOfLifeDSL.g:539:2: ( () otherlv_1= 'Rules:' (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )? ( (lv_rules_4_0= ruleRule ) )* )
            {
            // InternalGameOfLifeDSL.g:539:2: ( () otherlv_1= 'Rules:' (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )? ( (lv_rules_4_0= ruleRule ) )* )
            // InternalGameOfLifeDSL.g:540:3: () otherlv_1= 'Rules:' (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )? ( (lv_rules_4_0= ruleRule ) )*
            {
            // InternalGameOfLifeDSL.g:540:3: ()
            // InternalGameOfLifeDSL.g:541:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getRulesAccess().getRulesAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,21,FOLLOW_14); 

            			newLeafNode(otherlv_1, grammarAccess.getRulesAccess().getRulesKeyword_1());
            		
            // InternalGameOfLifeDSL.g:551:3: (otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==22) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalGameOfLifeDSL.g:552:4: otherlv_2= 'default:' ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) )
                    {
                    otherlv_2=(Token)match(input,22,FOLLOW_15); 

                    				newLeafNode(otherlv_2, grammarAccess.getRulesAccess().getDefaultKeyword_2_0());
                    			
                    // InternalGameOfLifeDSL.g:556:4: ( (lv_defaultConsequence_3_0= ruleDefaultConsequence ) )
                    // InternalGameOfLifeDSL.g:557:5: (lv_defaultConsequence_3_0= ruleDefaultConsequence )
                    {
                    // InternalGameOfLifeDSL.g:557:5: (lv_defaultConsequence_3_0= ruleDefaultConsequence )
                    // InternalGameOfLifeDSL.g:558:6: lv_defaultConsequence_3_0= ruleDefaultConsequence
                    {

                    						newCompositeNode(grammarAccess.getRulesAccess().getDefaultConsequenceDefaultConsequenceEnumRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_defaultConsequence_3_0=ruleDefaultConsequence();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRulesRule());
                    						}
                    						set(
                    							current,
                    							"defaultConsequence",
                    							lv_defaultConsequence_3_0,
                    							"life.game.GameOfLifeDSL.DefaultConsequence");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameOfLifeDSL.g:576:3: ( (lv_rules_4_0= ruleRule ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>=28 && LA9_0<=30)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalGameOfLifeDSL.g:577:4: (lv_rules_4_0= ruleRule )
            	    {
            	    // InternalGameOfLifeDSL.g:577:4: (lv_rules_4_0= ruleRule )
            	    // InternalGameOfLifeDSL.g:578:5: lv_rules_4_0= ruleRule
            	    {

            	    					newCompositeNode(grammarAccess.getRulesAccess().getRulesRuleParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_16);
            	    lv_rules_4_0=ruleRule();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRulesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rules",
            	    						lv_rules_4_0,
            	    						"life.game.GameOfLifeDSL.Rule");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRules"


    // $ANTLR start "entryRuleRule"
    // InternalGameOfLifeDSL.g:599:1: entryRuleRule returns [EObject current=null] : iv_ruleRule= ruleRule EOF ;
    public final EObject entryRuleRule() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRule = null;


        try {
            // InternalGameOfLifeDSL.g:599:45: (iv_ruleRule= ruleRule EOF )
            // InternalGameOfLifeDSL.g:600:2: iv_ruleRule= ruleRule EOF
            {
             newCompositeNode(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRule=ruleRule();

            state._fsp--;

             current =iv_ruleRule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalGameOfLifeDSL.g:606:1: ruleRule returns [EObject current=null] : ( ( (lv_consequence_0_0= ruleConsequence ) ) ( (lv_Reason_1_0= ruleReason ) ) ) ;
    public final EObject ruleRule() throws RecognitionException {
        EObject current = null;

        Enumerator lv_consequence_0_0 = null;

        EObject lv_Reason_1_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:612:2: ( ( ( (lv_consequence_0_0= ruleConsequence ) ) ( (lv_Reason_1_0= ruleReason ) ) ) )
            // InternalGameOfLifeDSL.g:613:2: ( ( (lv_consequence_0_0= ruleConsequence ) ) ( (lv_Reason_1_0= ruleReason ) ) )
            {
            // InternalGameOfLifeDSL.g:613:2: ( ( (lv_consequence_0_0= ruleConsequence ) ) ( (lv_Reason_1_0= ruleReason ) ) )
            // InternalGameOfLifeDSL.g:614:3: ( (lv_consequence_0_0= ruleConsequence ) ) ( (lv_Reason_1_0= ruleReason ) )
            {
            // InternalGameOfLifeDSL.g:614:3: ( (lv_consequence_0_0= ruleConsequence ) )
            // InternalGameOfLifeDSL.g:615:4: (lv_consequence_0_0= ruleConsequence )
            {
            // InternalGameOfLifeDSL.g:615:4: (lv_consequence_0_0= ruleConsequence )
            // InternalGameOfLifeDSL.g:616:5: lv_consequence_0_0= ruleConsequence
            {

            					newCompositeNode(grammarAccess.getRuleAccess().getConsequenceConsequenceEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_17);
            lv_consequence_0_0=ruleConsequence();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRuleRule());
            					}
            					set(
            						current,
            						"consequence",
            						lv_consequence_0_0,
            						"life.game.GameOfLifeDSL.Consequence");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameOfLifeDSL.g:633:3: ( (lv_Reason_1_0= ruleReason ) )
            // InternalGameOfLifeDSL.g:634:4: (lv_Reason_1_0= ruleReason )
            {
            // InternalGameOfLifeDSL.g:634:4: (lv_Reason_1_0= ruleReason )
            // InternalGameOfLifeDSL.g:635:5: lv_Reason_1_0= ruleReason
            {

            					newCompositeNode(grammarAccess.getRuleAccess().getReasonReasonParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_Reason_1_0=ruleReason();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRuleRule());
            					}
            					set(
            						current,
            						"Reason",
            						lv_Reason_1_0,
            						"life.game.GameOfLifeDSL.Reason");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleReason"
    // InternalGameOfLifeDSL.g:656:1: entryRuleReason returns [EObject current=null] : iv_ruleReason= ruleReason EOF ;
    public final EObject entryRuleReason() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReason = null;


        try {
            // InternalGameOfLifeDSL.g:656:47: (iv_ruleReason= ruleReason EOF )
            // InternalGameOfLifeDSL.g:657:2: iv_ruleReason= ruleReason EOF
            {
             newCompositeNode(grammarAccess.getReasonRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReason=ruleReason();

            state._fsp--;

             current =iv_ruleReason; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReason"


    // $ANTLR start "ruleReason"
    // InternalGameOfLifeDSL.g:663:1: ruleReason returns [EObject current=null] : (otherlv_0= 'if' otherlv_1= '[' ( (lv_condition_2_0= ruleCondition ) ) otherlv_3= ']' otherlv_4= 'companions' ) ;
    public final EObject ruleReason() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_condition_2_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:669:2: ( (otherlv_0= 'if' otherlv_1= '[' ( (lv_condition_2_0= ruleCondition ) ) otherlv_3= ']' otherlv_4= 'companions' ) )
            // InternalGameOfLifeDSL.g:670:2: (otherlv_0= 'if' otherlv_1= '[' ( (lv_condition_2_0= ruleCondition ) ) otherlv_3= ']' otherlv_4= 'companions' )
            {
            // InternalGameOfLifeDSL.g:670:2: (otherlv_0= 'if' otherlv_1= '[' ( (lv_condition_2_0= ruleCondition ) ) otherlv_3= ']' otherlv_4= 'companions' )
            // InternalGameOfLifeDSL.g:671:3: otherlv_0= 'if' otherlv_1= '[' ( (lv_condition_2_0= ruleCondition ) ) otherlv_3= ']' otherlv_4= 'companions'
            {
            otherlv_0=(Token)match(input,23,FOLLOW_9); 

            			newLeafNode(otherlv_0, grammarAccess.getReasonAccess().getIfKeyword_0());
            		
            otherlv_1=(Token)match(input,14,FOLLOW_18); 

            			newLeafNode(otherlv_1, grammarAccess.getReasonAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalGameOfLifeDSL.g:679:3: ( (lv_condition_2_0= ruleCondition ) )
            // InternalGameOfLifeDSL.g:680:4: (lv_condition_2_0= ruleCondition )
            {
            // InternalGameOfLifeDSL.g:680:4: (lv_condition_2_0= ruleCondition )
            // InternalGameOfLifeDSL.g:681:5: lv_condition_2_0= ruleCondition
            {

            					newCompositeNode(grammarAccess.getReasonAccess().getConditionConditionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_8);
            lv_condition_2_0=ruleCondition();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReasonRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_2_0,
            						"life.game.GameOfLifeDSL.Condition");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,16,FOLLOW_19); 

            			newLeafNode(otherlv_3, grammarAccess.getReasonAccess().getRightSquareBracketKeyword_3());
            		
            otherlv_4=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getReasonAccess().getCompanionsKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReason"


    // $ANTLR start "entryRuleCondition"
    // InternalGameOfLifeDSL.g:710:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalGameOfLifeDSL.g:710:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalGameOfLifeDSL.g:711:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalGameOfLifeDSL.g:717:1: ruleCondition returns [EObject current=null] : ( ( (lv_operator_0_0= ruleOperator ) ) ( (lv_neighbors_1_0= RULE_INT ) ) ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        Token lv_neighbors_1_0=null;
        EObject lv_operator_0_0 = null;



        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:723:2: ( ( ( (lv_operator_0_0= ruleOperator ) ) ( (lv_neighbors_1_0= RULE_INT ) ) ) )
            // InternalGameOfLifeDSL.g:724:2: ( ( (lv_operator_0_0= ruleOperator ) ) ( (lv_neighbors_1_0= RULE_INT ) ) )
            {
            // InternalGameOfLifeDSL.g:724:2: ( ( (lv_operator_0_0= ruleOperator ) ) ( (lv_neighbors_1_0= RULE_INT ) ) )
            // InternalGameOfLifeDSL.g:725:3: ( (lv_operator_0_0= ruleOperator ) ) ( (lv_neighbors_1_0= RULE_INT ) )
            {
            // InternalGameOfLifeDSL.g:725:3: ( (lv_operator_0_0= ruleOperator ) )
            // InternalGameOfLifeDSL.g:726:4: (lv_operator_0_0= ruleOperator )
            {
            // InternalGameOfLifeDSL.g:726:4: (lv_operator_0_0= ruleOperator )
            // InternalGameOfLifeDSL.g:727:5: lv_operator_0_0= ruleOperator
            {

            					newCompositeNode(grammarAccess.getConditionAccess().getOperatorOperatorParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_6);
            lv_operator_0_0=ruleOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConditionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_0_0,
            						"life.game.GameOfLifeDSL.Operator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameOfLifeDSL.g:744:3: ( (lv_neighbors_1_0= RULE_INT ) )
            // InternalGameOfLifeDSL.g:745:4: (lv_neighbors_1_0= RULE_INT )
            {
            // InternalGameOfLifeDSL.g:745:4: (lv_neighbors_1_0= RULE_INT )
            // InternalGameOfLifeDSL.g:746:5: lv_neighbors_1_0= RULE_INT
            {
            lv_neighbors_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_neighbors_1_0, grammarAccess.getConditionAccess().getNeighborsINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConditionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"neighbors",
            						lv_neighbors_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleOperator"
    // InternalGameOfLifeDSL.g:766:1: entryRuleOperator returns [EObject current=null] : iv_ruleOperator= ruleOperator EOF ;
    public final EObject entryRuleOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperator = null;


        try {
            // InternalGameOfLifeDSL.g:766:49: (iv_ruleOperator= ruleOperator EOF )
            // InternalGameOfLifeDSL.g:767:2: iv_ruleOperator= ruleOperator EOF
            {
             newCompositeNode(grammarAccess.getOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOperator=ruleOperator();

            state._fsp--;

             current =iv_ruleOperator; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperator"


    // $ANTLR start "ruleOperator"
    // InternalGameOfLifeDSL.g:773:1: ruleOperator returns [EObject current=null] : ( ( (lv_SMALLER_0_0= '<' ) ) | ( (lv_LARGER_1_0= '>' ) ) | ( (lv_EQUAL_2_0= '=' ) ) ) ;
    public final EObject ruleOperator() throws RecognitionException {
        EObject current = null;

        Token lv_SMALLER_0_0=null;
        Token lv_LARGER_1_0=null;
        Token lv_EQUAL_2_0=null;


        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:779:2: ( ( ( (lv_SMALLER_0_0= '<' ) ) | ( (lv_LARGER_1_0= '>' ) ) | ( (lv_EQUAL_2_0= '=' ) ) ) )
            // InternalGameOfLifeDSL.g:780:2: ( ( (lv_SMALLER_0_0= '<' ) ) | ( (lv_LARGER_1_0= '>' ) ) | ( (lv_EQUAL_2_0= '=' ) ) )
            {
            // InternalGameOfLifeDSL.g:780:2: ( ( (lv_SMALLER_0_0= '<' ) ) | ( (lv_LARGER_1_0= '>' ) ) | ( (lv_EQUAL_2_0= '=' ) ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 25:
                {
                alt10=1;
                }
                break;
            case 26:
                {
                alt10=2;
                }
                break;
            case 13:
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalGameOfLifeDSL.g:781:3: ( (lv_SMALLER_0_0= '<' ) )
                    {
                    // InternalGameOfLifeDSL.g:781:3: ( (lv_SMALLER_0_0= '<' ) )
                    // InternalGameOfLifeDSL.g:782:4: (lv_SMALLER_0_0= '<' )
                    {
                    // InternalGameOfLifeDSL.g:782:4: (lv_SMALLER_0_0= '<' )
                    // InternalGameOfLifeDSL.g:783:5: lv_SMALLER_0_0= '<'
                    {
                    lv_SMALLER_0_0=(Token)match(input,25,FOLLOW_2); 

                    					newLeafNode(lv_SMALLER_0_0, grammarAccess.getOperatorAccess().getSMALLERLessThanSignKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getOperatorRule());
                    					}
                    					setWithLastConsumed(current, "SMALLER", lv_SMALLER_0_0, "<");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:796:3: ( (lv_LARGER_1_0= '>' ) )
                    {
                    // InternalGameOfLifeDSL.g:796:3: ( (lv_LARGER_1_0= '>' ) )
                    // InternalGameOfLifeDSL.g:797:4: (lv_LARGER_1_0= '>' )
                    {
                    // InternalGameOfLifeDSL.g:797:4: (lv_LARGER_1_0= '>' )
                    // InternalGameOfLifeDSL.g:798:5: lv_LARGER_1_0= '>'
                    {
                    lv_LARGER_1_0=(Token)match(input,26,FOLLOW_2); 

                    					newLeafNode(lv_LARGER_1_0, grammarAccess.getOperatorAccess().getLARGERGreaterThanSignKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getOperatorRule());
                    					}
                    					setWithLastConsumed(current, "LARGER", lv_LARGER_1_0, ">");
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:811:3: ( (lv_EQUAL_2_0= '=' ) )
                    {
                    // InternalGameOfLifeDSL.g:811:3: ( (lv_EQUAL_2_0= '=' ) )
                    // InternalGameOfLifeDSL.g:812:4: (lv_EQUAL_2_0= '=' )
                    {
                    // InternalGameOfLifeDSL.g:812:4: (lv_EQUAL_2_0= '=' )
                    // InternalGameOfLifeDSL.g:813:5: lv_EQUAL_2_0= '='
                    {
                    lv_EQUAL_2_0=(Token)match(input,13,FOLLOW_2); 

                    					newLeafNode(lv_EQUAL_2_0, grammarAccess.getOperatorAccess().getEQUALEqualsSignKeyword_2_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getOperatorRule());
                    					}
                    					setWithLastConsumed(current, "EQUAL", lv_EQUAL_2_0, "=");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperator"


    // $ANTLR start "ruleDefaultConsequence"
    // InternalGameOfLifeDSL.g:829:1: ruleDefaultConsequence returns [Enumerator current=null] : ( (enumLiteral_0= 'empty' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'die' ) ) ;
    public final Enumerator ruleDefaultConsequence() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:835:2: ( ( (enumLiteral_0= 'empty' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'die' ) ) )
            // InternalGameOfLifeDSL.g:836:2: ( (enumLiteral_0= 'empty' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'die' ) )
            {
            // InternalGameOfLifeDSL.g:836:2: ( (enumLiteral_0= 'empty' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'die' ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt11=1;
                }
                break;
            case 28:
                {
                alt11=2;
                }
                break;
            case 29:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalGameOfLifeDSL.g:837:3: (enumLiteral_0= 'empty' )
                    {
                    // InternalGameOfLifeDSL.g:837:3: (enumLiteral_0= 'empty' )
                    // InternalGameOfLifeDSL.g:838:4: enumLiteral_0= 'empty'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getDefaultConsequenceAccess().getEMPTYEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getDefaultConsequenceAccess().getEMPTYEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:845:3: (enumLiteral_1= 'survive' )
                    {
                    // InternalGameOfLifeDSL.g:845:3: (enumLiteral_1= 'survive' )
                    // InternalGameOfLifeDSL.g:846:4: enumLiteral_1= 'survive'
                    {
                    enumLiteral_1=(Token)match(input,28,FOLLOW_2); 

                    				current = grammarAccess.getDefaultConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getDefaultConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:853:3: (enumLiteral_2= 'die' )
                    {
                    // InternalGameOfLifeDSL.g:853:3: (enumLiteral_2= 'die' )
                    // InternalGameOfLifeDSL.g:854:4: enumLiteral_2= 'die'
                    {
                    enumLiteral_2=(Token)match(input,29,FOLLOW_2); 

                    				current = grammarAccess.getDefaultConsequenceAccess().getDEATHEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getDefaultConsequenceAccess().getDEATHEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDefaultConsequence"


    // $ANTLR start "ruleConsequence"
    // InternalGameOfLifeDSL.g:864:1: ruleConsequence returns [Enumerator current=null] : ( (enumLiteral_0= 'die' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'be born' ) ) ;
    public final Enumerator ruleConsequence() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalGameOfLifeDSL.g:870:2: ( ( (enumLiteral_0= 'die' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'be born' ) ) )
            // InternalGameOfLifeDSL.g:871:2: ( (enumLiteral_0= 'die' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'be born' ) )
            {
            // InternalGameOfLifeDSL.g:871:2: ( (enumLiteral_0= 'die' ) | (enumLiteral_1= 'survive' ) | (enumLiteral_2= 'be born' ) )
            int alt12=3;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt12=1;
                }
                break;
            case 28:
                {
                alt12=2;
                }
                break;
            case 30:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalGameOfLifeDSL.g:872:3: (enumLiteral_0= 'die' )
                    {
                    // InternalGameOfLifeDSL.g:872:3: (enumLiteral_0= 'die' )
                    // InternalGameOfLifeDSL.g:873:4: enumLiteral_0= 'die'
                    {
                    enumLiteral_0=(Token)match(input,29,FOLLOW_2); 

                    				current = grammarAccess.getConsequenceAccess().getDEATHEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getConsequenceAccess().getDEATHEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalGameOfLifeDSL.g:880:3: (enumLiteral_1= 'survive' )
                    {
                    // InternalGameOfLifeDSL.g:880:3: (enumLiteral_1= 'survive' )
                    // InternalGameOfLifeDSL.g:881:4: enumLiteral_1= 'survive'
                    {
                    enumLiteral_1=(Token)match(input,28,FOLLOW_2); 

                    				current = grammarAccess.getConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getConsequenceAccess().getSURVIVALEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalGameOfLifeDSL.g:888:3: (enumLiteral_2= 'be born' )
                    {
                    // InternalGameOfLifeDSL.g:888:3: (enumLiteral_2= 'be born' )
                    // InternalGameOfLifeDSL.g:889:4: enumLiteral_2= 'be born'
                    {
                    enumLiteral_2=(Token)match(input,30,FOLLOW_2); 

                    				current = grammarAccess.getConsequenceAccess().getBORNEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getConsequenceAccess().getBORNEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConsequence"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000260000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000081002L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000070400002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000038000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000070000002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000006002000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001000000L});

}